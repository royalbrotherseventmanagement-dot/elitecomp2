import { supabase } from "@/integrations/supabase/client";

export async function uploadToBucket(
  bucket: string,
  userId: string,
  file: File,
  subdir?: string,
): Promise<{ path: string }> {
  const ext = file.name.split(".").pop() || "bin";
  const filename = `${crypto.randomUUID()}.${ext}`;
  const path = subdir ? `${userId}/${subdir}/${filename}` : `${userId}/${filename}`;
  const { error } = await supabase.storage.from(bucket).upload(path, file, {
    upsert: false,
    contentType: file.type || undefined,
  });
  if (error) throw error;
  return { path };
}

export async function signedUrl(bucket: string, path: string, expiresIn = 3600): Promise<string | null> {
  if (!path) return null;
  const { data } = await supabase.storage.from(bucket).createSignedUrl(path, expiresIn);
  return data?.signedUrl ?? null;
}
