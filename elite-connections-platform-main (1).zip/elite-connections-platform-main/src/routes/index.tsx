import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Sparkles, ShieldCheck, Search, MessageCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { SignedImage } from "@/components/SignedImage";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Luxe Companions — Premium Talent Agency" },
      { name: "description", content: "Book verified models, hosts, and brand ambassadors for premium events." },
      { property: "og:title", content: "Luxe Companions — Premium Talent Agency" },
      { property: "og:description", content: "Book verified models, hosts, and brand ambassadors for premium events." },
    ],
  }),
  component: Landing,
});

function Landing() {
  const { data: featured = [] } = useQuery({
    queryKey: ["featured-talent"],
    queryFn: async () => {
      const { data } = await supabase
        .from("talent")
        .select("id, stage_name, city, category, tier, avatar_url")
        .eq("status", "active")
        .eq("verification_status", "verified")
        .order("created_at", { ascending: false })
        .limit(6);
      return data ?? [];
    },
  });

  return (
    <div className="min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_top,oklch(0.22_0.05_75/_0.6),transparent_60%)]" />
      <header className="px-6 sm:px-8 py-6 flex items-center justify-between max-w-7xl mx-auto">
        <Link to="/" className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-[color:var(--gold)]" />
          <span className="font-display text-2xl gold-gradient">Luxe Companions</span>
        </Link>
        <div className="flex items-center gap-2">
          <Button asChild variant="ghost"><Link to="/browse">Browse</Link></Button>
          <Button asChild variant="outline"><Link to="/auth">Sign in</Link></Button>
        </div>
      </header>

      <section className="max-w-5xl mx-auto px-6 sm:px-8 pt-16 sm:pt-20 pb-16 text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-border px-3 py-1 text-xs uppercase tracking-[0.25em] text-muted-foreground mb-6">
          <span className="h-1.5 w-1.5 rounded-full bg-[color:var(--gold)]" /> Verified premium talent
        </div>
        <h1 className="font-display text-5xl sm:text-6xl md:text-7xl leading-[1.05]">
          The <span className="gold-gradient">private suite</span><br />for elite talent.
        </h1>
        <p className="mt-6 text-lg text-muted-foreground max-w-2xl mx-auto">
          A curated marketplace of verified models, hosts and brand ambassadors. Browse, request, and book — handled end-to-end by our agency.
        </p>
        <div className="mt-10 flex items-center justify-center gap-3">
          <Button asChild size="lg" className="px-8"><Link to="/browse">Browse talent</Link></Button>
          <Button asChild size="lg" variant="outline" className="px-8"><Link to="/auth">Join as talent</Link></Button>
        </div>
      </section>

      {featured.length > 0 && (
        <section className="max-w-6xl mx-auto px-6 sm:px-8 pb-20">
          <div className="flex items-end justify-between mb-6">
            <h2 className="font-display text-3xl">Featured talent</h2>
            <Link to="/browse" className="text-sm text-[color:var(--gold)] hover:underline">See all →</Link>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {featured.map((t: any) => (
              <Link
                key={t.id}
                to="/talent/$id"
                params={{ id: t.id }}
                className="luxe-card rounded-xl overflow-hidden group"
              >
                <div className="aspect-[4/5] bg-secondary overflow-hidden">
                  <SignedImage
                    bucket="avatars"
                    path={t.avatar_url}
                    alt={t.stage_name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    fallback={<div className="w-full h-full grid place-items-center text-muted-foreground"><Sparkles className="h-8 w-8" /></div>}
                  />
                </div>
                <div className="p-4 flex items-center justify-between">
                  <div>
                    <div className="font-display text-lg">{t.stage_name}</div>
                    <div className="text-xs text-muted-foreground">{t.category}{t.city ? ` · ${t.city}` : ""}</div>
                  </div>
                  <Badge variant="outline" className="capitalize">{t.tier}</Badge>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}

      <section className="max-w-5xl mx-auto px-6 sm:px-8 pb-24 grid md:grid-cols-3 gap-4">
        {[
          { icon: ShieldCheck, title: "Verified talent", body: "Every model passes identity verification before going live." },
          { icon: Search, title: "Curated discovery", body: "Browse by city, tier and category to find the perfect match." },
          { icon: MessageCircle, title: "Concierge bookings", body: "Submit a request — our team handles contracts and logistics." },
        ].map((f) => (
          <div key={f.title} className="luxe-card rounded-xl p-6">
            <f.icon className="h-5 w-5 text-[color:var(--gold)]" />
            <div className="mt-4 font-display text-xl">{f.title}</div>
            <div className="mt-1 text-sm text-muted-foreground">{f.body}</div>
          </div>
        ))}
      </section>

      <footer className="border-t border-border py-6 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} Luxe Companions. All rights reserved.
      </footer>
    </div>
  );
}
