import { createFileRoute, Link, useNavigate, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Sparkles, ArrowLeft, Calendar, Star } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { SignedImage } from "@/components/SignedImage";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/talent/$id")({
  loader: async ({ params }) => {
    const { data } = await supabase
      .from("talent")
      .select("id, stage_name, city, category, tier, avatar_url, bio, day_rate, hourly_rate, languages, height_cm")
      .eq("id", params.id)
      .eq("status", "active")
      .eq("verification_status", "verified")
      .maybeSingle();
    if (!data) throw notFound();
    return { talent: data };
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.talent.stage_name ?? "Talent"} — Luxe Companions` },
      { name: "description", content: loaderData?.talent.bio?.slice(0, 160) ?? "Book verified premium talent." },
      { property: "og:title", content: `${loaderData?.talent.stage_name} — Luxe Companions` },
      { property: "og:description", content: loaderData?.talent.bio?.slice(0, 160) ?? "" },
    ],
  }),
  errorComponent: () => <div className="p-12 text-center">Failed to load.</div>,
  notFoundComponent: () => (
    <div className="min-h-screen grid place-items-center text-center p-8">
      <div>
        <h1 className="font-display text-3xl">Profile not available</h1>
        <Button asChild className="mt-4"><Link to="/browse">Back to browse</Link></Button>
      </div>
    </div>
  ),
  component: TalentDetail,
});

function TalentDetail() {
  const { talent } = Route.useLoaderData();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ event_title: "", location: "", starts_at: "", ends_at: "", budget: "", message: "" });

  const { data: media = [] } = useQuery({
    queryKey: ["talent-media", talent.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("talent_media")
        .select("id, storage_path, caption")
        .eq("talent_id", talent.id)
        .eq("is_public", true)
        .order("sort_order");
      return data ?? [];
    },
  });

  const { data: reviews = [] } = useQuery({
    queryKey: ["talent-reviews", talent.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("reviews" as any)
        .select("id, rating, body, created_at")
        .eq("talent_id", talent.id)
        .eq("is_published", true)
        .order("created_at", { ascending: false })
        .limit(20);
      return (data ?? []) as any[];
    },
  });
  const avg = reviews.length ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length : 0;

  const submit = useMutation({
    mutationFn: async () => {
      if (!user) throw new Error("Sign in required");
      const { data: clientRow } = await supabase.from("clients").select("id").eq("profile_user_id", user.id).maybeSingle();
      const { error } = await supabase.from("booking_requests" as any).insert({
        talent_id: talent.id,
        client_id: clientRow?.id ?? null,
        requester_user_id: user.id,
        event_title: form.event_title,
        location: form.location || null,
        starts_at: form.starts_at,
        ends_at: form.ends_at,
        budget: form.budget ? Number(form.budget) : null,
        message: form.message || null,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Booking request sent. Our team will be in touch.");
      setOpen(false);
      setForm({ event_title: "", location: "", starts_at: "", ends_at: "", budget: "", message: "" });
    },
    onError: (e: any) => toast.error(e.message ?? "Failed to send"),
  });

  function onRequestClick() {
    if (!user) {
      toast.message("Please sign in to send a booking request.");
      navigate({ to: "/auth" });
      return;
    }
    setOpen(true);
  }

  return (
    <div className="min-h-screen">
      <header className="px-6 sm:px-8 py-6 flex items-center justify-between max-w-7xl mx-auto border-b border-border">
        <Link to="/browse" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Back to browse
        </Link>
        <Link to="/" className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-[color:var(--gold)]" />
          <span className="font-display text-xl gold-gradient">Luxe Companions</span>
        </Link>
      </header>

      <div className="max-w-6xl mx-auto px-6 sm:px-8 py-10 grid lg:grid-cols-[1fr_360px] gap-10">
        <div>
          <div className="aspect-[4/5] max-w-md rounded-xl overflow-hidden bg-secondary">
            <SignedImage
              bucket="avatars"
              path={talent.avatar_url}
              alt={talent.stage_name}
              className="w-full h-full object-cover"
              fallback={<div className="w-full h-full grid place-items-center text-muted-foreground"><Sparkles className="h-12 w-12" /></div>}
            />
          </div>

          <div className="mt-6 flex items-center gap-3 flex-wrap">
            <h1 className="font-display text-4xl">{talent.stage_name}</h1>
            <Badge variant="outline" className="capitalize">{talent.tier}</Badge>
            <Badge variant="secondary">Verified</Badge>
          </div>
          <p className="text-muted-foreground mt-1">{talent.category}{talent.city ? ` · ${talent.city}` : ""}</p>

          {talent.bio && <p className="mt-6 text-base leading-relaxed whitespace-pre-wrap">{talent.bio}</p>}

          <dl className="mt-8 grid grid-cols-2 sm:grid-cols-3 gap-4 text-sm">
            {talent.day_rate && (<div className="luxe-card rounded-lg p-3"><dt className="text-xs text-muted-foreground">Day rate</dt><dd className="font-display text-lg">${Number(talent.day_rate).toLocaleString()}</dd></div>)}
            {talent.hourly_rate && (<div className="luxe-card rounded-lg p-3"><dt className="text-xs text-muted-foreground">Hourly</dt><dd className="font-display text-lg">${Number(talent.hourly_rate).toLocaleString()}</dd></div>)}
            {talent.height_cm && (<div className="luxe-card rounded-lg p-3"><dt className="text-xs text-muted-foreground">Height</dt><dd className="font-display text-lg">{talent.height_cm} cm</dd></div>)}
            {talent.languages?.length > 0 && (<div className="luxe-card rounded-lg p-3 col-span-2"><dt className="text-xs text-muted-foreground">Languages</dt><dd className="font-display text-lg">{talent.languages.join(", ")}</dd></div>)}
          </dl>

          {media.length > 0 && (
            <>
              <h2 className="mt-10 font-display text-2xl">Portfolio</h2>
              <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 gap-3">
                {media.map((m: any) => (
                  <div key={m.id} className="aspect-square rounded-lg overflow-hidden bg-secondary">
                    <SignedImage bucket="talent-media" path={m.storage_path} alt={m.caption ?? talent.stage_name} className="w-full h-full object-cover" />
                  </div>
                ))}
              </div>
            </>
          )}

          <h2 className="mt-10 font-display text-2xl flex items-center gap-3">
            Reviews
            {reviews.length > 0 && (
              <span className="text-base text-muted-foreground inline-flex items-center gap-1">
                <Star className="h-4 w-4 fill-[color:var(--gold)] text-[color:var(--gold)]" />
                {avg.toFixed(1)} · {reviews.length}
              </span>
            )}
          </h2>
          <div className="mt-4 space-y-3">
            {reviews.length === 0 && <p className="text-sm text-muted-foreground">No reviews yet.</p>}
            {reviews.map((r) => (
              <div key={r.id} className="luxe-card rounded-lg p-4">
                <div className="flex items-center gap-1">
                  {[1,2,3,4,5].map((n) => (
                    <Star key={n} className={cn("h-4 w-4", n <= r.rating ? "fill-[color:var(--gold)] text-[color:var(--gold)]" : "text-muted-foreground")} />
                  ))}
                  <span className="text-xs text-muted-foreground ml-2">{new Date(r.created_at).toLocaleDateString()}</span>
                </div>
                {r.body && <p className="mt-2 text-sm whitespace-pre-wrap">{r.body}</p>}
              </div>
            ))}
          </div>
        </div>

        <aside className="lg:sticky lg:top-8 h-fit luxe-card rounded-xl p-6">
          <div className="font-display text-xl">Request this talent</div>
          <p className="text-sm text-muted-foreground mt-1">Our agency will confirm availability and send a quote.</p>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="w-full mt-4" size="lg" onClick={onRequestClick}>
                <Calendar className="h-4 w-4 mr-2" /> Send booking request
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
              <DialogHeader><DialogTitle className="font-display text-2xl">Booking request</DialogTitle></DialogHeader>
              <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); submit.mutate(); }}>
                <div className="space-y-1.5"><Label>Event title</Label><Input required value={form.event_title} onChange={(e) => setForm({ ...form, event_title: e.target.value })} /></div>
                <div className="space-y-1.5"><Label>Location</Label><Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} /></div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5"><Label>Starts</Label><Input type="datetime-local" required value={form.starts_at} onChange={(e) => setForm({ ...form, starts_at: e.target.value })} /></div>
                  <div className="space-y-1.5"><Label>Ends</Label><Input type="datetime-local" required value={form.ends_at} onChange={(e) => setForm({ ...form, ends_at: e.target.value })} /></div>
                </div>
                <div className="space-y-1.5"><Label>Budget (USD)</Label><Input type="number" step="0.01" value={form.budget} onChange={(e) => setForm({ ...form, budget: e.target.value })} /></div>
                <div className="space-y-1.5"><Label>Message</Label><Textarea rows={4} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} /></div>
                <DialogFooter>
                  <Button type="submit" className="w-full" disabled={submit.isPending}>
                    {submit.isPending ? "Sending…" : "Send request"}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </aside>
      </div>
    </div>
  );
}
