import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { MessageThread } from "@/components/MessageThread";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/_authenticated/messages/$bookingId")({
  component: MessagesPage,
});

function MessagesPage() {
  const { bookingId } = Route.useParams();

  const { data: booking } = useQuery({
    queryKey: ["booking", bookingId],
    queryFn: async () => {
      const { data } = await supabase
        .from("bookings")
        .select("id, event_title, location, starts_at, status, talent:talent_id(stage_name), client:client_id(full_name)")
        .eq("id", bookingId)
        .maybeSingle();
      return data;
    },
  });

  return (
    <AppShell title="Messages">
      <Link to="/my-bookings" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4">
        <ArrowLeft className="h-4 w-4" /> Back to bookings
      </Link>
      {booking && (
        <div className="mb-4">
          <div className="flex items-center gap-2 flex-wrap">
            <h2 className="font-display text-2xl">{(booking as any).event_title}</h2>
            <Badge variant="secondary" className="capitalize">{(booking as any).status}</Badge>
          </div>
          <p className="text-sm text-muted-foreground">
            {(booking as any).talent?.stage_name} · {(booking as any).client?.full_name}
            {" · "}{new Date((booking as any).starts_at).toLocaleString()}
          </p>
        </div>
      )}
      <MessageThread bookingId={bookingId} />
    </AppShell>
  );
}
