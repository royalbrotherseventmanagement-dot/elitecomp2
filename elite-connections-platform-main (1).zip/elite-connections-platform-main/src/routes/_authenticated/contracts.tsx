import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AppShell } from "@/components/AppShell";
import { CrudPage } from "@/components/CrudPage";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/_authenticated/contracts")({ component: ContractsPage });

function ContractsPage() {
  const { data: bookings = [] } = useQuery({
    queryKey: ["booking-options"],
    queryFn: async () => (await supabase.from("bookings").select("id, event_title").order("starts_at", { ascending: false })).data ?? [],
  });

  return (
    <AppShell title="Contracts">
      <CrudPage
        table="contracts"
        title="Contract"
        emptyText="No contracts yet."
        select="*, booking:booking_id(event_title)"
        defaultRow={{ booking_id: "", title: "", body: "", status: "draft", signer_name: "" }}
        columns={[
          { key: "title", label: "Title" },
          { key: "booking", label: "Booking", render: (r) => r.booking?.event_title ?? "—" },
          { key: "status", label: "Status", render: (r) => <Badge variant="secondary">{r.status}</Badge> },
          { key: "signer_name", label: "Signer" },
          { key: "signed_at", label: "Signed", render: (r) => r.signed_at ? new Date(r.signed_at).toLocaleDateString() : "—" },
        ]}
        formFields={(form, setForm) => (
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2 space-y-1.5"><Label>Title</Label><Input required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></div>
            <div className="col-span-2 space-y-1.5"><Label>Booking</Label>
              <Select value={form.booking_id} onValueChange={(v) => setForm({ ...form, booking_id: v })}>
                <SelectTrigger><SelectValue placeholder="Select booking…" /></SelectTrigger>
                <SelectContent>{bookings.map((b: any) => <SelectItem key={b.id} value={b.id}>{b.event_title}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label>Status</Label>
              <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{["draft","sent","signed","cancelled"].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label>Signer name</Label><Input value={form.signer_name} onChange={(e) => setForm({ ...form, signer_name: e.target.value })} /></div>
            <div className="col-span-2 space-y-1.5"><Label>Contract body</Label><Textarea rows={6} value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} /></div>
          </div>
        )}
      />
    </AppShell>
  );
}
