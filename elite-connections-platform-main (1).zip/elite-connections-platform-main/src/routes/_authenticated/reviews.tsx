import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Star, Check, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { useAuth, useUserRole, isStaff } from "@/lib/use-auth";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { ReviewAuditTrail } from "@/components/ReviewAuditTrail";

export const Route = createFileRoute("/_authenticated/reviews")({ component: ReviewsPage });

function ReviewsPage() {
  const { data: role } = useUserRole();
  const { user } = useAuth();
  const qc = useQueryClient();
  const [tab, setTab] = useState<"pending" | "approved" | "rejected">("pending");
  const [noteOpen, setNoteOpen] = useState<string | null>(null);
  const [note, setNote] = useState("");

  const { data: rows = [] } = useQuery({
    queryKey: ["reviews-mod", tab],
    enabled: isStaff(role),
    queryFn: async () => {
      const { data } = await supabase
        .from("reviews" as any)
        .select("id, rating, body, created_at, moderation_status, moderator_note, talent:talent_id(stage_name), client:client_id(full_name), booking:booking_id(event_title)")
        .eq("moderation_status", tab)
        .order("created_at", { ascending: false });
      return (data ?? []) as any[];
    },
  });

  const moderate = useMutation({
    mutationFn: async ({ id, status, moderator_note }: { id: string; status: "approved" | "rejected"; moderator_note?: string }) => {
      const { error } = await supabase.from("reviews" as any).update({
        moderation_status: status,
        is_published: status === "approved",
        moderator_note: moderator_note ?? null,
        moderated_by: user?.id ?? null,
        moderated_at: new Date().toISOString(),
      }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Review updated");
      qc.invalidateQueries({ queryKey: ["reviews-mod"] });
      setNoteOpen(null); setNote("");
    },
    onError: (e: any) => toast.error(e.message ?? "Failed"),
  });

  if (!isStaff(role)) {
    return <AppShell title="Reviews"><p className="text-sm text-muted-foreground">Staff only.</p></AppShell>;
  }

  return (
    <AppShell title="Review moderation">
      <Tabs value={tab} onValueChange={(v) => setTab(v as any)}>
        <TabsList>
          <TabsTrigger value="pending">Pending</TabsTrigger>
          <TabsTrigger value="approved">Approved</TabsTrigger>
          <TabsTrigger value="rejected">Rejected</TabsTrigger>
        </TabsList>
        <TabsContent value={tab} className="mt-4">
          <div className="luxe-card rounded-xl divide-y divide-border">
            {rows.length === 0 && <div className="p-6 text-sm text-muted-foreground">Nothing here.</div>}
            {rows.map((r: any) => (
              <div key={r.id} className="p-4">
                <div className="flex items-center justify-between gap-3 flex-wrap">
                  <div>
                    <div className="font-medium">{r.talent?.stage_name} ← {r.client?.full_name}</div>
                    <div className="text-xs text-muted-foreground">
                      {r.booking?.event_title} · {new Date(r.created_at).toLocaleString()}
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    {[1,2,3,4,5].map((n) => (
                      <Star key={n} className={cn("h-4 w-4", n <= r.rating ? "fill-[color:var(--gold)] text-[color:var(--gold)]" : "text-muted-foreground")} />
                    ))}
                  </div>
                </div>
                {r.body && <p className="mt-2 text-sm whitespace-pre-wrap">{r.body}</p>}
                {r.moderator_note && <p className="mt-2 text-xs text-muted-foreground italic">Note: {r.moderator_note}</p>}
                {tab === "pending" && (
                  <div className="mt-3 flex gap-2">
                    <Button size="sm" onClick={() => moderate.mutate({ id: r.id, status: "approved" })}>
                      <Check className="h-4 w-4 mr-1" /> Approve
                    </Button>
                    {noteOpen === r.id ? (
                      <div className="flex-1 flex gap-2">
                        <Textarea rows={1} placeholder="Reason (optional)" value={note} onChange={(e) => setNote(e.target.value)} />
                        <Button size="sm" variant="destructive" onClick={() => moderate.mutate({ id: r.id, status: "rejected", moderator_note: note })}>Confirm reject</Button>
                        <Button size="sm" variant="ghost" onClick={() => { setNoteOpen(null); setNote(""); }}>Cancel</Button>
                      </div>
                    ) : (
                      <Button size="sm" variant="outline" onClick={() => setNoteOpen(r.id)}>
                        <X className="h-4 w-4 mr-1" /> Reject
                      </Button>
                    )}
                  </div>
                )}
                {tab === "approved" && (
                  <div className="mt-2"><Badge variant="secondary">Published</Badge></div>
                )}
                <ReviewAuditTrail reviewId={r.id} />
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </AppShell>
  );
}
