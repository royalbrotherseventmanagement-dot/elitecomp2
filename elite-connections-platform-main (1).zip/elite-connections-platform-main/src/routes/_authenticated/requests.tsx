import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Check, X, Inbox } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { useAuth } from "@/lib/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/requests")({ component: RequestsPage });

function fmt(n: number) { return new Intl.NumberFormat(undefined, { style: "currency", currency: "USD" }).format(n || 0); }

function RequestsPage() {
  const qc = useQueryClient();
  const { user } = useAuth();
  const [tab, setTab] = useState("pending");
  const [approving, setApproving] = useState<any | null>(null);
  const [rejecting, setRejecting] = useState<any | null>(null);

  const { data: requests = [], isLoading } = useQuery({
    queryKey: ["booking-requests", tab],
    queryFn: async () => {
      let q = supabase.from("booking_requests").select(
        "*, talent:talent_id(id, stage_name), client:client_id(id, full_name, email)"
      ).order("created_at", { ascending: false });
      if (tab !== "all") q = q.eq("status", tab as any);
      const { data } = await q;
      return data ?? [];
    },
  });

  const reject = useMutation({
    mutationFn: async ({ id, reason }: { id: string; reason: string }) => {
      const { error } = await supabase.from("booking_requests" as any).update({
        status: "rejected", admin_note: reason || null, reviewed_by: user!.id, reviewed_at: new Date().toISOString(),
      }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Request rejected");
      qc.invalidateQueries({ queryKey: ["booking-requests"] });
      setRejecting(null);
    },
    onError: (e: any) => toast.error(e.message),
  });

  return (
    <AppShell title="Booking requests">
      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="pending">Pending</TabsTrigger>
          <TabsTrigger value="approved">Approved</TabsTrigger>
          <TabsTrigger value="rejected">Rejected</TabsTrigger>
          <TabsTrigger value="converted">Converted</TabsTrigger>
          <TabsTrigger value="all">All</TabsTrigger>
        </TabsList>
        <TabsContent value={tab} className="mt-4">
          <div className="luxe-card rounded-xl divide-y divide-border">
            {isLoading && <div className="p-6 text-muted-foreground">Loading…</div>}
            {!isLoading && requests.length === 0 && (
              <div className="p-10 text-center text-muted-foreground">
                <Inbox className="h-8 w-8 mx-auto mb-2 opacity-50" />
                No requests in this tab.
              </div>
            )}
            {requests.map((r: any) => (
              <div key={r.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="min-w-0 flex-1">
                  <div className="font-medium">{r.event_title}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">
                    {r.talent?.stage_name} ← {r.client?.full_name ?? r.client?.email ?? "guest"}
                    {" · "}{new Date(r.starts_at).toLocaleString()} → {new Date(r.ends_at).toLocaleString()}
                    {r.location ? ` · ${r.location}` : ""}
                  </div>
                  {r.message && <div className="text-sm mt-2 text-muted-foreground italic">"{r.message}"</div>}
                </div>
                <div className="flex items-center gap-3">
                  {r.budget && <span className="text-sm font-medium">{fmt(Number(r.budget))}</span>}
                  <Badge variant="secondary" className="capitalize">{r.status}</Badge>
                  {r.status === "pending" && (
                    <div className="flex gap-2">
                      <Button size="sm" onClick={() => setApproving(r)}><Check className="h-4 w-4 mr-1" /> Approve</Button>
                      <Button size="sm" variant="outline" onClick={() => setRejecting(r)}><X className="h-4 w-4 mr-1" /> Reject</Button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {approving && <ApproveDialog request={approving} onClose={() => setApproving(null)} userId={user!.id} />}

      <Dialog open={!!rejecting} onOpenChange={(o) => !o && setRejecting(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Reject request</DialogTitle></DialogHeader>
          <RejectForm onSubmit={(reason) => rejecting && reject.mutate({ id: rejecting.id, reason })} pending={reject.isPending} />
        </DialogContent>
      </Dialog>
    </AppShell>
  );
}

function RejectForm({ onSubmit, pending }: { onSubmit: (reason: string) => void; pending: boolean }) {
  const [reason, setReason] = useState("");
  return (
    <form onSubmit={(e) => { e.preventDefault(); onSubmit(reason); }} className="space-y-3">
      <div className="space-y-1.5"><Label>Reason (optional)</Label><Textarea rows={3} value={reason} onChange={(e) => setReason(e.target.value)} /></div>
      <DialogFooter><Button type="submit" variant="destructive" disabled={pending}>{pending ? "Rejecting…" : "Reject request"}</Button></DialogFooter>
    </form>
  );
}

function ApproveDialog({ request, onClose, userId }: { request: any; onClose: () => void; userId: string }) {
  const qc = useQueryClient();
  const [grossFee, setGrossFee] = useState(String(request.budget ?? "0"));
  const [commissionRate, setCommissionRate] = useState("30");
  const [note, setNote] = useState("");

  const convert = useMutation({
    mutationFn: async () => {
      // Ensure a client row exists for the requester
      let clientId = request.client_id;
      if (!clientId) {
        const { data: existing } = await supabase.from("clients").select("id").eq("profile_user_id", request.requester_user_id).maybeSingle();
        if (existing?.id) {
          clientId = existing.id;
        } else {
          const { data: created, error: ce } = await supabase.from("clients" as any).insert({
            full_name: request.client?.full_name ?? "Client", email: request.client?.email ?? null, profile_user_id: request.requester_user_id,
          }).select("id").single();
          if (ce) throw ce;
          clientId = (created as any).id;
        }
      }

      const { data: booking, error: be } = await supabase.from("bookings" as any).insert({
        talent_id: request.talent_id,
        client_id: clientId,
        event_title: request.event_title,
        location: request.location,
        starts_at: request.starts_at,
        ends_at: request.ends_at,
        gross_fee: Number(grossFee),
        commission_rate: Number(commissionRate),
        status: "confirmed",
        notes: note || null,
      }).select("id").single();
      if (be) throw be;

      const { error: ue } = await supabase.from("booking_requests" as any).update({
        status: "converted",
        booking_id: (booking as any).id,
        reviewed_by: userId,
        reviewed_at: new Date().toISOString(),
        admin_note: note || null,
      }).eq("id", request.id);
      if (ue) throw ue;
    },
    onSuccess: () => {
      toast.success("Request approved and booking created");
      qc.invalidateQueries({ queryKey: ["booking-requests"] });
      qc.invalidateQueries({ queryKey: ["bookings"] });
      onClose();
    },
    onError: (e: any) => toast.error(e.message ?? "Failed"),
  });

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader><DialogTitle>Approve & create booking</DialogTitle></DialogHeader>
        <form onSubmit={(e) => { e.preventDefault(); convert.mutate(); }} className="space-y-3">
          <div className="text-xs text-muted-foreground">
            <div><strong>{request.event_title}</strong></div>
            <div>{request.talent?.stage_name} for {request.client?.full_name ?? "—"}</div>
            <div>{new Date(request.starts_at).toLocaleString()}</div>
          </div>
          <div className="space-y-1.5"><Label>Confirmed gross fee (USD)</Label><Input type="number" step="0.01" required value={grossFee} onChange={(e) => setGrossFee(e.target.value)} /></div>
          <div className="space-y-1.5"><Label>Commission rate (%)</Label><Input type="number" step="0.01" required value={commissionRate} onChange={(e) => setCommissionRate(e.target.value)} /></div>
          <div className="space-y-1.5"><Label>Internal note</Label><Textarea rows={2} value={note} onChange={(e) => setNote(e.target.value)} /></div>
          <DialogFooter><Button type="submit" disabled={convert.isPending}>{convert.isPending ? "Creating…" : "Create booking"}</Button></DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
