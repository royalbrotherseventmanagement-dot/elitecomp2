import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AppShell } from "@/components/AppShell";
import { CrudPage } from "@/components/CrudPage";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/_authenticated/payouts")({ component: PayoutsPage });
function money(n: number) { return new Intl.NumberFormat(undefined, { style: "currency", currency: "USD" }).format(n || 0); }

function PayoutsPage() {
  const { data: talent = [] } = useQuery({ queryKey: ["talent-options"], queryFn: async () => (await supabase.from("talent").select("id, stage_name").order("stage_name")).data ?? [] });
  const { data: bookings = [] } = useQuery({ queryKey: ["booking-options"], queryFn: async () => (await supabase.from("bookings").select("id, event_title, talent_payout").order("starts_at", { ascending: false })).data ?? [] });

  return (
    <AppShell title="Talent Payouts">
      <p className="text-sm text-muted-foreground mb-4">Track payouts to talent. Automated Stripe Connect payouts can be added in a follow-up step.</p>
      <CrudPage
        table="payouts"
        title="Payout"
        emptyText="No payouts yet."
        select="*, talent:talent_id(stage_name), booking:booking_id(event_title)"
        defaultRow={{ talent_id: "", booking_id: "", amount: "0", status: "pending", method: "", reference: "", paid_at: "", notes: "" }}
        columns={[
          { key: "talent", label: "Talent", render: (r) => r.talent?.stage_name ?? "—" },
          { key: "booking", label: "Booking", render: (r) => r.booking?.event_title ?? "—" },
          { key: "amount", label: "Amount", render: (r) => money(Number(r.amount)) },
          { key: "method", label: "Method" },
          { key: "status", label: "Status", render: (r) => <Badge variant="secondary">{r.status}</Badge> },
          { key: "paid_at", label: "Paid on", render: (r) => r.paid_at ? new Date(r.paid_at).toLocaleDateString() : "—" },
        ]}
        formFields={(form, setForm) => (
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5"><Label>Talent</Label>
              <Select value={form.talent_id} onValueChange={(v) => setForm({ ...form, talent_id: v })}>
                <SelectTrigger><SelectValue placeholder="Select…" /></SelectTrigger>
                <SelectContent>{talent.map((t: any) => <SelectItem key={t.id} value={t.id}>{t.stage_name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label>Booking (optional)</Label>
              <Select value={form.booking_id} onValueChange={(v) => {
                const b = bookings.find((x: any) => x.id === v);
                setForm({ ...form, booking_id: v, amount: b?.talent_payout ?? form.amount });
              }}>
                <SelectTrigger><SelectValue placeholder="None" /></SelectTrigger>
                <SelectContent>{bookings.map((b: any) => <SelectItem key={b.id} value={b.id}>{b.event_title}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label>Amount</Label><Input type="number" step="0.01" required value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Method</Label><Input placeholder="Bank, Stripe, Wise…" value={form.method} onChange={(e) => setForm({ ...form, method: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Reference</Label><Input value={form.reference} onChange={(e) => setForm({ ...form, reference: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Paid on</Label><Input type="date" value={form.paid_at} onChange={(e) => setForm({ ...form, paid_at: e.target.value })} /></div>
            <div className="col-span-2 space-y-1.5"><Label>Status</Label>
              <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{["pending","processing","paid","failed"].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="col-span-2 space-y-1.5"><Label>Notes</Label><Textarea rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
          </div>
        )}
      />
    </AppShell>
  );
}
