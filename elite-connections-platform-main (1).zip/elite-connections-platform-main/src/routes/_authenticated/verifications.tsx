import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ShieldCheck, ShieldX, ExternalLink } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { useAuth } from "@/lib/use-auth";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { SignedImage } from "@/components/SignedImage";
import { signedUrl } from "@/lib/storage";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/verifications")({ component: VerificationsPage });

function VerificationsPage() {
  const qc = useQueryClient();
  const { user } = useAuth();
  const [tab, setTab] = useState<"submitted" | "verified" | "rejected" | "all">("submitted");
  const [rejectTarget, setRejectTarget] = useState<any | null>(null);

  const { data: rows = [], isLoading } = useQuery({
    queryKey: ["verifications", tab],
    queryFn: async () => {
      let q = supabase.from("talent").select(
        "id, stage_name, legal_name, email, avatar_url, id_document_url, id_document_back_url, verification_status, verification_submitted_at, verification_rejection_reason, status"
      ).order("verification_submitted_at", { ascending: false });
      if (tab !== "all") q = q.eq("verification_status", tab);
      const { data } = await q;
      return data ?? [];
    },
  });

  const approve = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("talent" as any).update({
        verification_status: "verified",
        status: "active",
        verification_reviewed_at: new Date().toISOString(),
        verification_reviewed_by: user!.id,
        verification_rejection_reason: null,
      }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Talent verified and made live");
      qc.invalidateQueries({ queryKey: ["verifications"] });
    },
    onError: (e: any) => toast.error(e.message),
  });

  const reject = useMutation({
    mutationFn: async ({ id, reason }: { id: string; reason: string }) => {
      const { error } = await supabase.from("talent" as any).update({
        verification_status: "rejected",
        verification_rejection_reason: reason,
        verification_reviewed_at: new Date().toISOString(),
        verification_reviewed_by: user!.id,
      }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Verification rejected");
      qc.invalidateQueries({ queryKey: ["verifications"] });
      setRejectTarget(null);
    },
    onError: (e: any) => toast.error(e.message),
  });

  async function openDoc(path: string) {
    const url = await signedUrl("verification-docs", path, 300);
    if (url) window.open(url, "_blank");
    else toast.error("Could not load document");
  }

  return (
    <AppShell title="Verification queue">
      <Tabs value={tab} onValueChange={(v) => setTab(v as any)}>
        <TabsList>
          <TabsTrigger value="submitted">Pending</TabsTrigger>
          <TabsTrigger value="verified">Verified</TabsTrigger>
          <TabsTrigger value="rejected">Rejected</TabsTrigger>
          <TabsTrigger value="all">All</TabsTrigger>
        </TabsList>

        <TabsContent value={tab} className="mt-4">
          {isLoading && <div className="luxe-card rounded-xl p-6 text-muted-foreground">Loading…</div>}
          {!isLoading && rows.length === 0 && (
            <div className="luxe-card rounded-xl p-10 text-center text-muted-foreground">
              <ShieldCheck className="h-8 w-8 mx-auto mb-2 opacity-50" />
              Nothing in this tab.
            </div>
          )}
          <div className="grid sm:grid-cols-2 gap-4">
            {rows.map((r: any) => (
              <div key={r.id} className="luxe-card rounded-xl p-4 flex gap-4">
                <div className="w-24 h-24 shrink-0 rounded-lg overflow-hidden bg-secondary">
                  <SignedImage bucket="avatars" path={r.avatar_url} alt={r.stage_name} className="w-full h-full object-cover" fallback={<div className="w-full h-full grid place-items-center text-xs text-muted-foreground">No photo</div>} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <div className="font-medium truncate">{r.stage_name}</div>
                      <div className="text-xs text-muted-foreground truncate">{r.legal_name ?? "—"} · {r.email ?? "—"}</div>
                      {r.verification_submitted_at && (
                        <div className="text-xs text-muted-foreground mt-0.5">Submitted {new Date(r.verification_submitted_at).toLocaleDateString()}</div>
                      )}
                    </div>
                    <Badge variant="outline" className="capitalize text-xs">{r.verification_status}</Badge>
                  </div>

                  <div className="flex flex-wrap gap-2 mt-3">
                    {r.id_document_url ? (
                      <Button size="sm" variant="outline" onClick={() => openDoc(r.id_document_url)}><ExternalLink className="h-3 w-3 mr-1" /> ID front</Button>
                    ) : <Badge variant="secondary">No ID front</Badge>}
                    {r.id_document_back_url && (
                      <Button size="sm" variant="outline" onClick={() => openDoc(r.id_document_back_url)}><ExternalLink className="h-3 w-3 mr-1" /> ID back</Button>
                    )}
                  </div>

                  {r.verification_status === "rejected" && r.verification_rejection_reason && (
                    <p className="text-xs text-destructive mt-2">{r.verification_rejection_reason}</p>
                  )}

                  {(r.verification_status === "submitted" || r.verification_status === "rejected") && (
                    <div className="flex gap-2 mt-3">
                      <Button size="sm" onClick={() => approve.mutate(r.id)} disabled={approve.isPending}><ShieldCheck className="h-3 w-3 mr-1" /> Approve</Button>
                      <Button size="sm" variant="outline" onClick={() => setRejectTarget(r)}><ShieldX className="h-3 w-3 mr-1" /> Reject</Button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      <Dialog open={!!rejectTarget} onOpenChange={(o) => !o && setRejectTarget(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Reject verification</DialogTitle></DialogHeader>
          <RejectForm onSubmit={(reason) => rejectTarget && reject.mutate({ id: rejectTarget.id, reason })} pending={reject.isPending} />
        </DialogContent>
      </Dialog>
    </AppShell>
  );
}

function RejectForm({ onSubmit, pending }: { onSubmit: (reason: string) => void; pending: boolean }) {
  const [reason, setReason] = useState("");
  return (
    <form onSubmit={(e) => { e.preventDefault(); if (!reason.trim()) return; onSubmit(reason); }} className="space-y-3">
      <div className="space-y-1.5"><Label>Reason (shown to talent)</Label><Textarea rows={3} required value={reason} onChange={(e) => setReason(e.target.value)} placeholder="ID document was unreadable, please re-upload a clear photo." /></div>
      <DialogFooter><Button type="submit" variant="destructive" disabled={pending}>{pending ? "Rejecting…" : "Reject"}</Button></DialogFooter>
    </form>
  );
}
