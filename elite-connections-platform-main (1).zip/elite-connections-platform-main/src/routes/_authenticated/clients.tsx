import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { CrudPage } from "@/components/CrudPage";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

export const Route = createFileRoute("/_authenticated/clients")({ component: ClientsPage });

function ClientsPage() {
  return (
    <AppShell title="Clients">
      <CrudPage
        table="clients"
        title="Client"
        emptyText="No clients yet."
        defaultRow={{ full_name: "", company: "", email: "", phone: "", city: "", tier: "standard", notes: "" }}
        columns={[
          { key: "full_name", label: "Name", render: (r) => (
            <div><div className="font-medium">{r.full_name}</div><div className="text-xs text-muted-foreground">{r.company}</div></div>
          )},
          { key: "email", label: "Email" },
          { key: "phone", label: "Phone" },
          { key: "city", label: "City" },
          { key: "tier", label: "Tier" },
        ]}
        formFields={(form, setForm) => (
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2 space-y-1.5"><Label>Full name</Label><Input required value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} /></div>
            <div className="col-span-2 space-y-1.5"><Label>Company</Label><Input value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Email</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Phone</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>City</Label><Input value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Tier</Label><Input value={form.tier} onChange={(e) => setForm({ ...form, tier: e.target.value })} /></div>
            <div className="col-span-2 space-y-1.5"><Label>Notes</Label><Textarea rows={3} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
          </div>
        )}
      />
    </AppShell>
  );
}
