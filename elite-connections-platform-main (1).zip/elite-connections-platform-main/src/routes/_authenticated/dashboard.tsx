import { createFileRoute, redirect, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { CalendarDays, Users, Wallet, Receipt, Inbox, ShieldCheck, Search, UserCheck } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { useUserRole, isStaff, useAuth } from "@/lib/use-auth";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/dashboard")({ component: Dashboard });

function fmt(n: number) {
  return new Intl.NumberFormat(undefined, { style: "currency", currency: "USD" }).format(n || 0);
}

function Dashboard() {
  const { data: role, isLoading: roleLoading } = useUserRole();
  if (roleLoading) return <AppShell title="Dashboard"><div className="text-muted-foreground">Loading…</div></AppShell>;
  if (isStaff(role)) return <StaffDashboard />;
  if (role === "talent") return <TalentDashboard />;
  return <ClientDashboard />;
}

function StaffDashboard() {
  const { data: stats } = useQuery({
    queryKey: ["staff-dashboard"],
    queryFn: async () => {
      const [talent, clients, bookings, payouts, invoices, requests, verifications] = await Promise.all([
        supabase.from("talent").select("id", { count: "exact", head: true }),
        supabase.from("clients").select("id", { count: "exact", head: true }),
        supabase.from("bookings").select("id, status, gross_fee, commission_amount, talent_payout, starts_at, event_title").order("starts_at", { ascending: false }).limit(5),
        supabase.from("payouts").select("amount, status"),
        supabase.from("invoices").select("amount, status"),
        supabase.from("booking_requests").select("id", { count: "exact", head: true }).eq("status", "pending"),
        supabase.from("talent").select("id", { count: "exact", head: true }).eq("verification_status", "submitted"),
      ]);
      const totalRevenue = (bookings.data ?? []).reduce((s, b: any) => s + Number(b.gross_fee || 0), 0);
      const totalCommission = (bookings.data ?? []).reduce((s, b: any) => s + Number(b.commission_amount || 0), 0);
      const pendingPayouts = (payouts.data ?? []).filter((p: any) => p.status === "pending").reduce((s, p: any) => s + Number(p.amount || 0), 0);
      const outstandingInvoices = (invoices.data ?? []).filter((i: any) => i.status !== "paid" && i.status !== "void").reduce((s, i: any) => s + Number(i.amount || 0), 0);
      return {
        talentCount: talent.count ?? 0,
        clientCount: clients.count ?? 0,
        recentBookings: bookings.data ?? [],
        totalRevenue, totalCommission, pendingPayouts, outstandingInvoices,
        pendingRequests: requests.count ?? 0,
        pendingVerifications: verifications.count ?? 0,
      };
    },
  });

  const cards = [
    { label: "Talent", value: stats?.talentCount ?? 0, icon: Users },
    { label: "Clients", value: stats?.clientCount ?? 0, icon: Users },
    { label: "Pending requests", value: stats?.pendingRequests ?? 0, icon: Inbox, link: "/requests" as const },
    { label: "Verifications to review", value: stats?.pendingVerifications ?? 0, icon: ShieldCheck, link: "/verifications" as const },
    { label: "Recent revenue", value: fmt(stats?.totalRevenue ?? 0), icon: CalendarDays },
    { label: "Agency commission (30%)", value: fmt(stats?.totalCommission ?? 0), icon: Wallet, accent: true },
    { label: "Pending payouts", value: fmt(stats?.pendingPayouts ?? 0), icon: Wallet },
    { label: "Outstanding invoices", value: fmt(stats?.outstandingInvoices ?? 0), icon: Receipt },
  ];

  return (
    <AppShell title="Dashboard">
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map((c) => {
          const inner = (
            <div className="luxe-card rounded-xl p-5 h-full hover:border-[color:var(--gold)]/40 transition-colors">
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase tracking-wider text-muted-foreground">{c.label}</span>
                <c.icon className={"h-4 w-4 " + ((c as any).accent ? "text-[color:var(--gold)]" : "text-muted-foreground")} />
              </div>
              <div className={"mt-3 font-display text-3xl " + ((c as any).accent ? "gold-gradient" : "")}>{c.value}</div>
            </div>
          );
          return c.link ? <Link key={c.label} to={c.link}>{inner}</Link> : <div key={c.label}>{inner}</div>;
        })}
      </div>

      <div className="mt-8">
        <h2 className="font-display text-xl mb-4">Recent bookings</h2>
        <div className="luxe-card rounded-xl divide-y divide-border">
          {(stats?.recentBookings ?? []).length === 0 && (
            <div className="p-6 text-sm text-muted-foreground">No bookings yet.</div>
          )}
          {(stats?.recentBookings ?? []).map((b: any) => (
            <div key={b.id} className="p-4 flex items-center justify-between">
              <div>
                <div className="font-medium">{b.event_title}</div>
                <div className="text-xs text-muted-foreground">{new Date(b.starts_at).toLocaleString()} · {b.status}</div>
              </div>
              <div className="text-right">
                <div className="text-sm">{fmt(Number(b.gross_fee))}</div>
                <div className="text-xs text-[color:var(--gold)]">Commission {fmt(Number(b.commission_amount))}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </AppShell>
  );
}

function TalentDashboard() {
  const { user } = useAuth();
  const { data } = useQuery({
    queryKey: ["talent-dashboard", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data: t } = await supabase.from("talent").select("id, stage_name, status, verification_status").eq("profile_user_id", user!.id).maybeSingle();
      if (!t) return { talent: null, upcoming: [], earnings: 0 };
      const { data: b } = await supabase.from("bookings").select("id, event_title, starts_at, talent_payout, status").eq("talent_id", t.id).order("starts_at", { ascending: false }).limit(5);
      const earnings = (b ?? []).reduce((s, x: any) => s + Number(x.talent_payout || 0), 0);
      return { talent: t, upcoming: b ?? [], earnings };
    },
  });

  const vStatus = data?.talent?.verification_status;
  const vBadge: Record<string, { label: string; cls: string }> = {
    unsubmitted: { label: "Not submitted", cls: "bg-secondary" },
    submitted: { label: "Under review", cls: "bg-amber-500/15 text-amber-400 border-amber-500/40" },
    verified: { label: "Verified ✓", cls: "bg-emerald-500/15 text-emerald-400 border-emerald-500/40" },
    rejected: { label: "Rejected", cls: "bg-destructive/15 text-destructive border-destructive/40" },
  };

  return (
    <AppShell title={`Hi, ${data?.talent?.stage_name ?? "talent"}`}>
      <div className="grid sm:grid-cols-3 gap-4">
        <div className="luxe-card rounded-xl p-5">
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Verification</div>
          {vStatus && <Badge variant="outline" className={"mt-3 " + (vBadge[vStatus]?.cls ?? "")}>{vBadge[vStatus]?.label}</Badge>}
          <Button asChild size="sm" variant="outline" className="mt-4 w-full"><Link to="/my-profile">Manage profile</Link></Button>
        </div>
        <div className="luxe-card rounded-xl p-5">
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Earnings (recent)</div>
          <div className="mt-3 font-display text-3xl gold-gradient">{fmt(data?.earnings ?? 0)}</div>
        </div>
        <div className="luxe-card rounded-xl p-5">
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Bookings</div>
          <div className="mt-3 font-display text-3xl">{data?.upcoming.length ?? 0}</div>
          <Button asChild size="sm" variant="outline" className="mt-4 w-full"><Link to="/my-bookings">View all</Link></Button>
        </div>
      </div>

      {vStatus !== "verified" && (
        <div className="mt-6 luxe-card rounded-xl p-6 border-[color:var(--gold)]/40">
          <div className="flex items-start gap-3">
            <UserCheck className="h-5 w-5 text-[color:var(--gold)] mt-0.5" />
            <div className="flex-1">
              <div className="font-display text-lg">Complete your verification</div>
              <p className="text-sm text-muted-foreground mt-1">Upload your ID and a portfolio photo to go live in the marketplace.</p>
            </div>
            <Button asChild><Link to="/my-profile">Start</Link></Button>
          </div>
        </div>
      )}
    </AppShell>
  );
}

function ClientDashboard() {
  const { user } = useAuth();
  const { data } = useQuery({
    queryKey: ["client-dashboard", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const [requests, bookings] = await Promise.all([
        supabase.from("booking_requests").select("id, event_title, status, starts_at, talent:talent_id(stage_name)").eq("requester_user_id", user!.id).order("created_at", { ascending: false }).limit(5),
        supabase.from("bookings").select("id, event_title, starts_at, status, talent:talent_id(stage_name)").order("starts_at", { ascending: false }).limit(5),
      ]);
      return { requests: requests.data ?? [], bookings: bookings.data ?? [] };
    },
  });

  return (
    <AppShell title="Your account">
      <div className="grid sm:grid-cols-2 gap-4">
        <Link to="/browse" className="luxe-card rounded-xl p-6 hover:border-[color:var(--gold)]/40">
          <Search className="h-5 w-5 text-[color:var(--gold)]" />
          <div className="mt-3 font-display text-xl">Discover talent</div>
          <p className="text-sm text-muted-foreground mt-1">Browse verified models, hosts and brand ambassadors.</p>
        </Link>
        <Link to="/my-bookings" className="luxe-card rounded-xl p-6 hover:border-[color:var(--gold)]/40">
          <CalendarDays className="h-5 w-5 text-[color:var(--gold)]" />
          <div className="mt-3 font-display text-xl">Your bookings</div>
          <p className="text-sm text-muted-foreground mt-1">View requests and confirmed bookings.</p>
        </Link>
      </div>

      <h2 className="mt-10 font-display text-xl mb-4">Recent requests</h2>
      <div className="luxe-card rounded-xl divide-y divide-border">
        {(data?.requests ?? []).length === 0 && <div className="p-6 text-sm text-muted-foreground">No requests yet. <Link to="/browse" className="text-[color:var(--gold)] underline">Browse talent</Link>.</div>}
        {(data?.requests ?? []).map((r: any) => (
          <div key={r.id} className="p-4 flex items-center justify-between">
            <div>
              <div className="font-medium">{r.event_title}</div>
              <div className="text-xs text-muted-foreground">{r.talent?.stage_name} · {new Date(r.starts_at).toLocaleString()}</div>
            </div>
            <Badge variant="secondary" className="capitalize">{r.status}</Badge>
          </div>
        ))}
      </div>
    </AppShell>
  );
}
