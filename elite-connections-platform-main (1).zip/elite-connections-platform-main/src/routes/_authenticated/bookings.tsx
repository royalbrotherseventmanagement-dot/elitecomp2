import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { MessageCircle } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { CrudPage } from "@/components/CrudPage";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/bookings")({ component: BookingsPage });

function money(n: number) { return new Intl.NumberFormat(undefined, { style: "currency", currency: "USD" }).format(n || 0); }

function BookingsPage() {
  const { data: talent = [] } = useQuery({ queryKey: ["talent-options"], queryFn: async () => (await supabase.from("talent").select("id, stage_name").order("stage_name")).data ?? [] });
  const { data: clients = [] } = useQuery({ queryKey: ["client-options"], queryFn: async () => (await supabase.from("clients").select("id, full_name").order("full_name")).data ?? [] });

  return (
    <AppShell title="Bookings">
      <p className="text-sm text-muted-foreground mb-4">A 30% agency commission is calculated automatically from the gross fee.</p>
      <CrudPage
        table="bookings"
        title="Booking"
        emptyText="No bookings yet."
        select="*, talent:talent_id(stage_name), client:client_id(full_name)"
        orderBy="starts_at"
        defaultRow={{ talent_id: "", client_id: "", event_title: "", location: "", starts_at: "", ends_at: "", gross_fee: "0", commission_rate: 30, status: "inquiry", notes: "" }}
        columns={[
          { key: "event_title", label: "Event", render: (r) => (
            <div><div className="font-medium">{r.event_title}</div><div className="text-xs text-muted-foreground">{r.location}</div></div>
          )},
          { key: "talent", label: "Talent", render: (r) => r.talent?.stage_name ?? "—" },
          { key: "client", label: "Client", render: (r) => r.client?.full_name ?? "—" },
          { key: "starts_at", label: "When", render: (r) => new Date(r.starts_at).toLocaleString() },
          { key: "gross_fee", label: "Gross", render: (r) => money(Number(r.gross_fee)) },
          { key: "commission_amount", label: "Commission", render: (r) => <span className="text-[color:var(--gold)]">{money(Number(r.commission_amount))}</span> },
          { key: "talent_payout", label: "Payout", render: (r) => money(Number(r.talent_payout)) },
          { key: "status", label: "Status", render: (r) => <Badge variant="secondary" className="capitalize">{r.status}</Badge> },
          { key: "chat", label: "", render: (r) => (
            <Button asChild size="sm" variant="ghost"><Link to="/messages/$bookingId" params={{ bookingId: r.id }}><MessageCircle className="h-4 w-4" /></Link></Button>
          )},
        ]}
        formFields={(form, setForm) => (
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2 space-y-1.5"><Label>Event title</Label><Input required value={form.event_title} onChange={(e) => setForm({ ...form, event_title: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Talent</Label>
              <Select value={form.talent_id} onValueChange={(v) => setForm({ ...form, talent_id: v })}>
                <SelectTrigger><SelectValue placeholder="Select…" /></SelectTrigger>
                <SelectContent>{talent.map((t: any) => <SelectItem key={t.id} value={t.id}>{t.stage_name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label>Client</Label>
              <Select value={form.client_id} onValueChange={(v) => setForm({ ...form, client_id: v })}>
                <SelectTrigger><SelectValue placeholder="Select…" /></SelectTrigger>
                <SelectContent>{clients.map((c: any) => <SelectItem key={c.id} value={c.id}>{c.full_name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="col-span-2 space-y-1.5"><Label>Location</Label><Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Starts at</Label><Input type="datetime-local" required value={form.starts_at} onChange={(e) => setForm({ ...form, starts_at: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Ends at</Label><Input type="datetime-local" required value={form.ends_at} onChange={(e) => setForm({ ...form, ends_at: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Gross fee</Label><Input type="number" step="0.01" required value={form.gross_fee} onChange={(e) => setForm({ ...form, gross_fee: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Commission rate (%)</Label><Input type="number" step="0.01" value={form.commission_rate} onChange={(e) => setForm({ ...form, commission_rate: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Status</Label>
              <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {["inquiry","confirmed","in_progress","completed","cancelled"].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="col-span-2 space-y-1.5"><Label>Notes</Label><Textarea rows={3} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
          </div>
        )}
      />
    </AppShell>
  );
}
