import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { CrudPage } from "@/components/CrudPage";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/_authenticated/roster")({ component: TalentPage });

const tierColor: Record<string, string> = {
  signature: "bg-[color:var(--gold)]/15 text-[color:var(--gold)] border-[color:var(--gold)]/40",
  premier: "bg-accent text-accent-foreground",
  standard: "",
};

function TalentPage() {
  return (
    <AppShell title="Talent Roster">
      <CrudPage
        table="talent"
        title="Talent"
        emptyText="No talent yet. Add your first model, host, or entertainer."
        defaultRow={{ stage_name: "", legal_name: "", email: "", phone: "", gender: "female", tier: "standard", status: "active", category: "", city: "", day_rate: "", hourly_rate: "", bio: "" }}
        columns={[
          { key: "stage_name", label: "Name", render: (r) => (
            <div>
              <div className="font-medium">{r.stage_name}</div>
              <div className="text-xs text-muted-foreground">{r.legal_name}</div>
            </div>
          )},
          { key: "tier", label: "Tier", render: (r) => <Badge variant="outline" className={tierColor[r.tier] || ""}>{r.tier}</Badge> },
          { key: "category", label: "Category" },
          { key: "city", label: "City" },
          { key: "day_rate", label: "Day rate", render: (r) => r.day_rate ? `$${Number(r.day_rate).toLocaleString()}` : "—" },
          { key: "status", label: "Status", render: (r) => <Badge variant="secondary">{r.status}</Badge> },
        ]}
        formFields={(form, setForm) => (
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2 space-y-1.5"><Label>Stage name</Label><Input required value={form.stage_name} onChange={(e) => setForm({ ...form, stage_name: e.target.value })} /></div>
            <div className="col-span-2 space-y-1.5"><Label>Legal name</Label><Input value={form.legal_name} onChange={(e) => setForm({ ...form, legal_name: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Email</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Phone</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Gender</Label>
              <Select value={form.gender} onValueChange={(v) => setForm({ ...form, gender: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="female">Female</SelectItem><SelectItem value="male">Male</SelectItem><SelectItem value="non_binary">Non-binary</SelectItem><SelectItem value="other">Other</SelectItem></SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label>Tier</Label>
              <Select value={form.tier} onValueChange={(v) => setForm({ ...form, tier: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="signature">Signature</SelectItem><SelectItem value="premier">Premier</SelectItem><SelectItem value="standard">Standard</SelectItem></SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label>Category</Label><Input placeholder="Host, Model, Brand Ambassador…" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>City</Label><Input value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Day rate</Label><Input type="number" step="0.01" value={form.day_rate} onChange={(e) => setForm({ ...form, day_rate: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Hourly rate</Label><Input type="number" step="0.01" value={form.hourly_rate} onChange={(e) => setForm({ ...form, hourly_rate: e.target.value })} /></div>
            <div className="col-span-2 space-y-1.5"><Label>Bio</Label><Textarea rows={3} value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Status</Label>
              <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="active">Active</SelectItem><SelectItem value="on_hold">On hold</SelectItem><SelectItem value="inactive">Inactive</SelectItem></SelectContent>
              </Select>
            </div>
          </div>
        )}
      />
    </AppShell>
  );
}
