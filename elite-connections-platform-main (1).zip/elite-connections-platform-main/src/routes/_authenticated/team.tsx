import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ShieldCheck, UserPlus, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { useUserRole } from "@/lib/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/team")({ component: TeamPage });

function TeamPage() {
  const { data: role } = useUserRole();
  const qc = useQueryClient();
  const [search, setSearch] = useState("");

  const { data: rows = [] } = useQuery({
    queryKey: ["team-members"],
    enabled: role === "admin",
    queryFn: async () => {
      const { data: roles } = await supabase
        .from("user_roles")
        .select("user_id, role")
        .in("role", ["admin", "agent"]);
      const ids = Array.from(new Set((roles ?? []).map((r: any) => r.user_id)));
      if (ids.length === 0) return [];
      const { data: profiles } = await supabase
        .from("profiles")
        .select("id, full_name, avatar_url")
        .in("id", ids);
      return (roles ?? []).map((r: any) => ({
        ...r,
        profile: profiles?.find((p: any) => p.id === r.user_id),
      }));
    },
  });

  const promote = useMutation({
    mutationFn: async (email: string) => {
      // Find profile by exact full_name OR fall back via auth-managed search using id (admin lookup needs service role).
      // Lookup profile by searching profiles table (we have no email here unless full_name matches).
      const { data: prof } = await supabase
        .from("profiles")
        .select("id, full_name")
        .ilike("full_name", email)
        .maybeSingle();
      if (!prof) throw new Error("No user found. Ask them to sign up first, then enter their exact display name.");
      const { error } = await supabase.from("user_roles" as any).insert({ user_id: (prof as any).id, role: "agent" });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Promoted to agency manager");
      qc.invalidateQueries({ queryKey: ["team-members"] });
      setSearch("");
    },
    onError: (e: any) => toast.error(e.message ?? "Failed"),
  });

  const revoke = useMutation({
    mutationFn: async ({ user_id, role: r }: { user_id: string; role: string }) => {
      const { error } = await supabase.from("user_roles" as any).delete().eq("user_id", user_id).eq("role", r);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Role removed");
      qc.invalidateQueries({ queryKey: ["team-members"] });
    },
    onError: (e: any) => toast.error(e.message ?? "Failed"),
  });

  if (role && role !== "admin") {
    return <AppShell title="Team"><p className="text-sm text-muted-foreground">Only administrators can manage the team.</p></AppShell>;
  }

  return (
    <AppShell title="Team & Roles">
      <p className="text-sm text-muted-foreground mb-6">Promote trusted users to Agency Manager. They can manage roster, bookings, requests and verifications.</p>

      <form
        onSubmit={(e) => { e.preventDefault(); if (search.trim()) promote.mutate(search.trim()); }}
        className="luxe-card rounded-xl p-4 flex gap-2 mb-6"
      >
        <Input
          placeholder="Enter exact display name to promote"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <Button type="submit" disabled={promote.isPending}>
          <UserPlus className="h-4 w-4 mr-2" /> Promote
        </Button>
      </form>

      <div className="luxe-card rounded-xl divide-y divide-border">
        {rows.length === 0 && <div className="p-6 text-sm text-muted-foreground">No team members yet.</div>}
        {rows.map((r: any) => (
          <div key={`${r.user_id}-${r.role}`} className="p-4 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <ShieldCheck className="h-5 w-5 text-[color:var(--gold)]" />
              <div className="min-w-0">
                <div className="font-medium truncate">{r.profile?.full_name ?? r.user_id}</div>
                <Badge variant="outline" className="capitalize mt-1">{r.role}</Badge>
              </div>
            </div>
            {r.role === "agent" && (
              <Button variant="ghost" size="icon" onClick={() => revoke.mutate({ user_id: r.user_id, role: r.role })}>
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>
        ))}
      </div>
    </AppShell>
  );
}
