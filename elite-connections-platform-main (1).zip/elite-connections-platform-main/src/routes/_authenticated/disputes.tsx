import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ShieldAlert, MessageCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { useAuth, useUserRole, isStaff } from "@/lib/use-auth";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { toast } from "sonner";
import { DisputeEvidence } from "@/components/DisputeEvidence";

export const Route = createFileRoute("/_authenticated/disputes")({ component: DisputesPage });

function DisputesPage() {
  const { user } = useAuth();
  const { data: role } = useUserRole();
  const qc = useQueryClient();
  const [tab, setTab] = useState<"open" | "under_review" | "resolved" | "rejected">("open");
  const [resolveOn, setResolveOn] = useState<string | null>(null);
  const [resolution, setResolution] = useState("");
  const [resolveStatus, setResolveStatus] = useState<"resolved" | "rejected">("resolved");

  const { data: rows = [] } = useQuery({
    queryKey: ["disputes", tab, user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase
        .from("disputes" as any)
        .select("id, category, reason, status, resolution, created_at, opened_by, booking:booking_id(id, event_title, talent:talent_id(stage_name), client:client_id(full_name))")
        .eq("status", tab)
        .order("created_at", { ascending: false });
      return (data ?? []) as any[];
    },
  });

  const update = useMutation({
    mutationFn: async ({ id, status, resolution }: { id: string; status: string; resolution?: string }) => {
      const payload: any = { status };
      if (status === "resolved" || status === "rejected") {
        payload.resolution = resolution ?? null;
        payload.resolved_by = user?.id ?? null;
        payload.resolved_at = new Date().toISOString();
      }
      const { error } = await supabase.from("disputes" as any).update(payload).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Dispute updated");
      qc.invalidateQueries({ queryKey: ["disputes"] });
      setResolveOn(null); setResolution("");
    },
    onError: (e: any) => toast.error(e.message ?? "Failed"),
  });

  return (
    <AppShell title="Disputes">
      {!isStaff(role) && (
        <p className="text-sm text-muted-foreground mb-4">Disputes you have opened or are part of will appear here.</p>
      )}
      <Tabs value={tab} onValueChange={(v) => setTab(v as any)}>
        <TabsList>
          <TabsTrigger value="open">Open</TabsTrigger>
          <TabsTrigger value="under_review">Under review</TabsTrigger>
          <TabsTrigger value="resolved">Resolved</TabsTrigger>
          <TabsTrigger value="rejected">Rejected</TabsTrigger>
        </TabsList>
        <TabsContent value={tab} className="mt-4">
          <div className="luxe-card rounded-xl divide-y divide-border">
            {rows.length === 0 && <div className="p-6 text-sm text-muted-foreground">Nothing here.</div>}
            {rows.map((d: any) => (
              <div key={d.id} className="p-4">
                <div className="flex items-start justify-between gap-3 flex-wrap">
                  <div className="min-w-0">
                    <div className="font-medium flex items-center gap-2">
                      <ShieldAlert className="h-4 w-4 text-[color:var(--gold)]" /> {d.category}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {d.booking?.event_title} · {d.booking?.talent?.stage_name} ↔ {d.booking?.client?.full_name}
                      {" · "}{new Date(d.created_at).toLocaleString()}
                    </div>
                  </div>
                  <Badge variant="secondary" className="capitalize">{d.status.replace("_", " ")}</Badge>
                </div>
                <p className="mt-2 text-sm whitespace-pre-wrap">{d.reason}</p>
                {d.resolution && (
                  <p className="mt-2 text-sm bg-secondary rounded p-2"><b>Resolution:</b> {d.resolution}</p>
                )}
                <DisputeEvidence disputeId={d.id} />
                <div className="mt-3 flex flex-wrap gap-2">
                  {d.booking?.id && (
                    <Button asChild size="sm" variant="ghost">
                      <Link to="/messages/$bookingId" params={{ bookingId: d.booking.id }}>
                        <MessageCircle className="h-4 w-4 mr-1" /> Open chat
                      </Link>
                    </Button>
                  )}
                  {isStaff(role) && d.status === "open" && (
                    <Button size="sm" variant="outline" onClick={() => update.mutate({ id: d.id, status: "under_review" })}>
                      Mark under review
                    </Button>
                  )}
                  {isStaff(role) && (d.status === "open" || d.status === "under_review") && (
                    resolveOn === d.id ? (
                      <div className="flex-1 flex flex-wrap gap-2 items-start min-w-[260px]">
                        <Select value={resolveStatus} onValueChange={(v) => setResolveStatus(v as any)}>
                          <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="resolved">Resolve</SelectItem>
                            <SelectItem value="rejected">Reject</SelectItem>
                          </SelectContent>
                        </Select>
                        <Textarea rows={1} placeholder="Resolution notes" value={resolution} onChange={(e) => setResolution(e.target.value)} className="flex-1" />
                        <Button size="sm" onClick={() => update.mutate({ id: d.id, status: resolveStatus, resolution })}>Save</Button>
                        <Button size="sm" variant="ghost" onClick={() => { setResolveOn(null); setResolution(""); }}>Cancel</Button>
                      </div>
                    ) : (
                      <Button size="sm" onClick={() => setResolveOn(d.id)}>Resolve / reject</Button>
                    )
                  )}
                </div>
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </AppShell>
  );
}
