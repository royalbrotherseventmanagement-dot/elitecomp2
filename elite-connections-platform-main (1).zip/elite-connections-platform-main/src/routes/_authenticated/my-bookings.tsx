import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { MessageCircle, Star, ShieldAlert } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { useAuth, useUserRole, isStaff } from "@/lib/use-auth";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ReviewDialog } from "@/components/ReviewDialog";
import { DisputeDialog } from "@/components/DisputeDialog";

export const Route = createFileRoute("/_authenticated/my-bookings")({ component: MyBookings });

function fmt(n: number) { return new Intl.NumberFormat(undefined, { style: "currency", currency: "USD" }).format(n || 0); }

function MyBookings() {
  const { user } = useAuth();
  const { data: role } = useUserRole();
  const [reviewing, setReviewing] = useState<any | null>(null);
  const [disputing, setDisputing] = useState<any | null>(null);

  const { data: bookings = [] } = useQuery({
    queryKey: ["my-bookings", user?.id, role],
    enabled: !!user && !!role,
    queryFn: async () => {
      const sel = "id, event_title, location, starts_at, ends_at, status, gross_fee, talent_payout, talent_id, client_id, talent:talent_id(stage_name), client:client_id(full_name)";
      const { data } = await supabase.from("bookings").select(sel).order("starts_at", { ascending: false });
      return data ?? [];
    },
  });

  const { data: reviews = [] } = useQuery({
    queryKey: ["my-reviews", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase.from("reviews" as any).select("booking_id, rating");
      return (data ?? []) as any[];
    },
  });
  const reviewedIds = new Set(reviews.map((r) => r.booking_id));

  const { data: requests = [] } = useQuery({
    queryKey: ["my-requests", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase
        .from("booking_requests")
        .select("id, event_title, location, starts_at, status, budget, talent:talent_id(stage_name)")
        .order("created_at", { ascending: false });
      return data ?? [];
    },
  });

  const isTalent = role === "talent";
  const isClient = role === "client";

  return (
    <AppShell title="My bookings" actions={isClient && <Button asChild><Link to="/browse">Browse talent</Link></Button>}>
      {!isStaff(role) && requests.length > 0 && (
        <section className="mb-10">
          <h2 className="font-display text-xl mb-3">{isClient ? "Your requests" : "Incoming requests"}</h2>
          <div className="luxe-card rounded-xl divide-y divide-border">
            {requests.map((r: any) => (
              <div key={r.id} className="p-4 flex items-center justify-between gap-4">
                <div className="min-w-0">
                  <div className="font-medium truncate">{r.event_title}</div>
                  <div className="text-xs text-muted-foreground">
                    {r.talent?.stage_name} · {new Date(r.starts_at).toLocaleString()}
                    {r.location ? ` · ${r.location}` : ""}
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  {r.budget && <span className="text-sm text-muted-foreground">{fmt(Number(r.budget))}</span>}
                  <Badge variant="secondary" className="capitalize">{r.status}</Badge>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      <h2 className="font-display text-xl mb-3">Confirmed bookings</h2>
      <div className="luxe-card rounded-xl divide-y divide-border">
        {bookings.length === 0 && <div className="p-6 text-sm text-muted-foreground">No bookings yet.</div>}
        {bookings.map((b: any) => {
          const canReview = isClient && b.status === "completed" && !reviewedIds.has(b.id);
          const reviewed = reviewedIds.has(b.id);
          return (
            <div key={b.id} className="p-4 flex flex-wrap items-center justify-between gap-4">
              <div className="min-w-0 flex-1">
                <div className="font-medium truncate">{b.event_title}</div>
                <div className="text-xs text-muted-foreground">
                  {isTalent ? b.client?.full_name : b.talent?.stage_name} · {new Date(b.starts_at).toLocaleString()}
                  {b.location ? ` · ${b.location}` : ""}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="text-right mr-2">
                  <div className="text-sm">{fmt(Number(isTalent ? b.talent_payout : b.gross_fee))}</div>
                  <Badge variant="secondary" className="capitalize mt-1">{b.status}</Badge>
                </div>
                <Button asChild size="sm" variant="outline">
                  <Link to="/messages/$bookingId" params={{ bookingId: b.id }}>
                    <MessageCircle className="h-4 w-4 mr-1" /> Message
                  </Link>
                </Button>
                {canReview && (
                  <Button size="sm" onClick={() => setReviewing(b)}>
                    <Star className="h-4 w-4 mr-1" /> Review
                  </Button>
                )}
                {reviewed && (
                  <Badge variant="outline" className="gap-1">
                    <Star className="h-3 w-3 fill-[color:var(--gold)] text-[color:var(--gold)]" /> Reviewed
                  </Badge>
                )}
                {!isStaff(role) && ["confirmed","in_progress","completed"].includes(b.status) && (
                  <Button size="sm" variant="ghost" onClick={() => setDisputing(b)}>
                    <ShieldAlert className="h-4 w-4 mr-1" /> Report
                  </Button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {reviewing && (
        <ReviewDialog
          open
          onClose={() => setReviewing(null)}
          bookingId={reviewing.id}
          talentId={reviewing.talent_id}
          clientId={reviewing.client_id}
          talentName={reviewing.talent?.stage_name}
        />
      )}
      {disputing && (
        <DisputeDialog
          open
          onClose={() => setDisputing(null)}
          bookingId={disputing.id}
          eventTitle={disputing.event_title}
        />
      )}
    </AppShell>
  );
}
