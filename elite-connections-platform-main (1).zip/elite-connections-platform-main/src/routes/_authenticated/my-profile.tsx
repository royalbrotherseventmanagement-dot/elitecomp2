import { createFileRoute } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Upload, Trash2, ShieldCheck } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { useAuth } from "@/lib/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { SignedImage } from "@/components/SignedImage";
import { uploadToBucket } from "@/lib/storage";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/my-profile")({ component: MyProfile });

function MyProfile() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const avatarInput = useRef<HTMLInputElement>(null);
  const portfolioInput = useRef<HTMLInputElement>(null);
  const idFrontInput = useRef<HTMLInputElement>(null);
  const idBackInput = useRef<HTMLInputElement>(null);

  const { data: talent, isLoading } = useQuery({
    queryKey: ["my-talent", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase.from("talent").select("*").eq("profile_user_id", user!.id).maybeSingle();
      return data;
    },
  });

  const { data: media = [] } = useQuery({
    queryKey: ["my-media", talent?.id],
    enabled: !!talent?.id,
    queryFn: async () => {
      const { data } = await supabase.from("talent_media").select("*").eq("talent_id", talent!.id).order("sort_order");
      return data ?? [];
    },
  });

  const [form, setForm] = useState<any>(null);
  const f = form ?? talent ?? {};

  const save = useMutation({
    mutationFn: async (patch: Record<string, any>) => {
      const { error } = await supabase.from("talent" as any).update(patch).eq("id", talent!.id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Profile saved");
      qc.invalidateQueries({ queryKey: ["my-talent", user?.id] });
      setForm(null);
    },
    onError: (e: any) => toast.error(e.message ?? "Failed"),
  });

  const uploadAvatar = useMutation({
    mutationFn: async (file: File) => {
      const { path } = await uploadToBucket("avatars", user!.id, file);
      const { error } = await supabase.from("talent" as any).update({ avatar_url: path }).eq("id", talent!.id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Avatar updated");
      qc.invalidateQueries({ queryKey: ["my-talent", user?.id] });
    },
    onError: (e: any) => toast.error(e.message ?? "Upload failed"),
  });

  const uploadPortfolio = useMutation({
    mutationFn: async (files: FileList) => {
      const existing = media.length;
      let i = 0;
      for (const file of Array.from(files)) {
        const { path } = await uploadToBucket("talent-media", user!.id, file, "portfolio");
        const { error } = await supabase.from("talent_media" as any).insert({
          talent_id: talent!.id, url: path, storage_path: path, sort_order: existing + i, is_public: true,
        });
        if (error) throw error;
        i++;
      }
    },
    onSuccess: () => {
      toast.success("Photos uploaded");
      qc.invalidateQueries({ queryKey: ["my-media", talent?.id] });
    },
    onError: (e: any) => toast.error(e.message ?? "Upload failed"),
  });

  const deleteMedia = useMutation({
    mutationFn: async (m: any) => {
      if (m.storage_path) await supabase.storage.from("talent-media").remove([m.storage_path]);
      const { error } = await supabase.from("talent_media" as any).delete().eq("id", m.id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["my-media", talent?.id] }),
    onError: (e: any) => toast.error(e.message ?? "Failed"),
  });

  const uploadIdDoc = useMutation({
    mutationFn: async ({ file, side }: { file: File; side: "front" | "back" }) => {
      const { path } = await uploadToBucket("verification-docs", user!.id, file, "id");
      const col = side === "front" ? "id_document_url" : "id_document_back_url";
      const { error } = await supabase.from("talent" as any).update({ [col]: path }).eq("id", talent!.id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Document uploaded");
      qc.invalidateQueries({ queryKey: ["my-talent", user?.id] });
    },
    onError: (e: any) => toast.error(e.message ?? "Upload failed"),
  });

  const submitVerification = useMutation({
    mutationFn: async () => {
      if (!talent?.id_document_url) throw new Error("Upload your ID first");
      if (!talent?.avatar_url) throw new Error("Upload a profile photo first");
      const { error } = await supabase.from("talent" as any).update({
        verification_status: "submitted",
        verification_submitted_at: new Date().toISOString(),
      }).eq("id", talent.id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Verification submitted for review");
      qc.invalidateQueries({ queryKey: ["my-talent", user?.id] });
    },
    onError: (e: any) => toast.error(e.message ?? "Failed"),
  });

  if (isLoading) return <AppShell title="My profile"><div className="text-muted-foreground">Loading…</div></AppShell>;
  if (!talent) return <AppShell title="My profile"><div className="text-muted-foreground">No talent profile found for your account.</div></AppShell>;

  const v = talent.verification_status;
  const canSubmit = v === "unsubmitted" || v === "rejected";

  return (
    <AppShell title="My profile">
      <div className="grid lg:grid-cols-[280px_1fr] gap-8">
        <div>
          <div className="luxe-card rounded-xl p-4">
            <div className="aspect-square rounded-lg overflow-hidden bg-secondary mb-3">
              <SignedImage
                bucket="avatars" path={talent.avatar_url} alt={talent.stage_name}
                className="w-full h-full object-cover"
                fallback={<div className="w-full h-full grid place-items-center text-muted-foreground text-xs">No photo</div>}
              />
            </div>
            <input ref={avatarInput} type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && uploadAvatar.mutate(e.target.files[0])} />
            <Button size="sm" variant="outline" className="w-full" onClick={() => avatarInput.current?.click()} disabled={uploadAvatar.isPending}>
              <Upload className="h-4 w-4 mr-2" /> {uploadAvatar.isPending ? "Uploading…" : "Change photo"}
            </Button>
          </div>

          <div className="luxe-card rounded-xl p-4 mt-4">
            <div className="flex items-center gap-2 mb-2">
              <ShieldCheck className="h-4 w-4 text-[color:var(--gold)]" />
              <div className="font-display text-lg">Verification</div>
            </div>
            <Badge variant="outline" className="capitalize">{v.replace("_", " ")}</Badge>
            {v === "rejected" && talent.verification_rejection_reason && (
              <p className="text-xs text-destructive mt-2">{talent.verification_rejection_reason}</p>
            )}
            <div className="mt-4 space-y-2">
              <div className="text-xs text-muted-foreground">ID document (front)</div>
              <input ref={idFrontInput} type="file" accept="image/*,.pdf" className="hidden" onChange={(e) => e.target.files?.[0] && uploadIdDoc.mutate({ file: e.target.files[0], side: "front" })} />
              <Button size="sm" variant="outline" className="w-full" onClick={() => idFrontInput.current?.click()} disabled={!canSubmit}>
                <Upload className="h-3 w-3 mr-2" />{talent.id_document_url ? "Replace" : "Upload"}
              </Button>
              <div className="text-xs text-muted-foreground mt-2">ID document (back)</div>
              <input ref={idBackInput} type="file" accept="image/*,.pdf" className="hidden" onChange={(e) => e.target.files?.[0] && uploadIdDoc.mutate({ file: e.target.files[0], side: "back" })} />
              <Button size="sm" variant="outline" className="w-full" onClick={() => idBackInput.current?.click()} disabled={!canSubmit}>
                <Upload className="h-3 w-3 mr-2" />{talent.id_document_back_url ? "Replace" : "Upload"}
              </Button>
            </div>
            {canSubmit && (
              <Button className="w-full mt-4" onClick={() => submitVerification.mutate()} disabled={submitVerification.isPending}>
                Submit for review
              </Button>
            )}
          </div>
        </div>

        <div>
          <form className="luxe-card rounded-xl p-6 grid sm:grid-cols-2 gap-4" onSubmit={(e) => { e.preventDefault(); save.mutate(form ?? {}); }}>
            <div className="sm:col-span-2 space-y-1.5"><Label>Stage name</Label><Input value={f.stage_name ?? ""} onChange={(e) => setForm({ ...f, stage_name: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Category</Label><Input value={f.category ?? ""} onChange={(e) => setForm({ ...f, category: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>City</Label><Input value={f.city ?? ""} onChange={(e) => setForm({ ...f, city: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Day rate (USD)</Label><Input type="number" step="0.01" value={f.day_rate ?? ""} onChange={(e) => setForm({ ...f, day_rate: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Hourly rate (USD)</Label><Input type="number" step="0.01" value={f.hourly_rate ?? ""} onChange={(e) => setForm({ ...f, hourly_rate: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Height (cm)</Label><Input type="number" value={f.height_cm ?? ""} onChange={(e) => setForm({ ...f, height_cm: e.target.value ? Number(e.target.value) : null })} /></div>
            <div className="space-y-1.5"><Label>Languages (comma separated)</Label><Input value={Array.isArray(f.languages) ? f.languages.join(", ") : (f.languages ?? "")} onChange={(e) => setForm({ ...f, languages: e.target.value.split(",").map((s: string) => s.trim()).filter(Boolean) })} /></div>
            <div className="sm:col-span-2 space-y-1.5"><Label>Bio</Label><Textarea rows={5} value={f.bio ?? ""} onChange={(e) => setForm({ ...f, bio: e.target.value })} /></div>
            <div className="sm:col-span-2 flex justify-end gap-2">
              {form && <Button type="button" variant="ghost" onClick={() => setForm(null)}>Discard</Button>}
              <Button type="submit" disabled={!form || save.isPending}>{save.isPending ? "Saving…" : "Save changes"}</Button>
            </div>
          </form>

          <div className="luxe-card rounded-xl p-6 mt-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <div className="font-display text-xl">Portfolio</div>
                <p className="text-xs text-muted-foreground">Visible on your public profile when verified.</p>
              </div>
              <input ref={portfolioInput} type="file" accept="image/*" multiple className="hidden" onChange={(e) => e.target.files && uploadPortfolio.mutate(e.target.files)} />
              <Button onClick={() => portfolioInput.current?.click()} disabled={uploadPortfolio.isPending}>
                <Upload className="h-4 w-4 mr-2" />{uploadPortfolio.isPending ? "Uploading…" : "Add photos"}
              </Button>
            </div>
            {media.length === 0 ? (
              <div className="text-sm text-muted-foreground text-center py-8">No photos yet.</div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {media.map((m: any) => (
                  <div key={m.id} className="relative aspect-square rounded-lg overflow-hidden bg-secondary group">
                    <SignedImage bucket="talent-media" path={m.storage_path} alt={m.caption ?? "photo"} className="w-full h-full object-cover" />
                    <Button size="icon" variant="destructive" className="absolute top-2 right-2 opacity-0 group-hover:opacity-100" onClick={() => confirm("Delete this photo?") && deleteMedia.mutate(m)}>
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </AppShell>
  );
}
