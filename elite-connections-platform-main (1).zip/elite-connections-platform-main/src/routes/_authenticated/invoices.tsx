import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AppShell } from "@/components/AppShell";
import { CrudPage } from "@/components/CrudPage";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/_authenticated/invoices")({ component: InvoicesPage });
function money(n: number) { return new Intl.NumberFormat(undefined, { style: "currency", currency: "USD" }).format(n || 0); }

function InvoicesPage() {
  const { data: clients = [] } = useQuery({ queryKey: ["client-options"], queryFn: async () => (await supabase.from("clients").select("id, full_name").order("full_name")).data ?? [] });
  const { data: bookings = [] } = useQuery({ queryKey: ["booking-options"], queryFn: async () => (await supabase.from("bookings").select("id, event_title").order("starts_at", { ascending: false })).data ?? [] });

  return (
    <AppShell title="Invoices">
      <CrudPage
        table="invoices"
        title="Invoice"
        emptyText="No invoices yet."
        select="*, client:client_id(full_name), booking:booking_id(event_title)"
        defaultRow={{ client_id: "", booking_id: "", amount: "0", status: "draft", due_at: "", notes: "" }}
        columns={[
          { key: "invoice_number", label: "Invoice #" },
          { key: "client", label: "Client", render: (r) => r.client?.full_name ?? "—" },
          { key: "booking", label: "Booking", render: (r) => r.booking?.event_title ?? "—" },
          { key: "amount", label: "Amount", render: (r) => money(Number(r.amount)) },
          { key: "status", label: "Status", render: (r) => <Badge variant="secondary">{r.status}</Badge> },
          { key: "due_at", label: "Due", render: (r) => r.due_at ? new Date(r.due_at).toLocaleDateString() : "—" },
        ]}
        formFields={(form, setForm) => (
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5"><Label>Client</Label>
              <Select value={form.client_id} onValueChange={(v) => setForm({ ...form, client_id: v })}>
                <SelectTrigger><SelectValue placeholder="Select…" /></SelectTrigger>
                <SelectContent>{clients.map((c: any) => <SelectItem key={c.id} value={c.id}>{c.full_name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label>Booking (optional)</Label>
              <Select value={form.booking_id} onValueChange={(v) => setForm({ ...form, booking_id: v })}>
                <SelectTrigger><SelectValue placeholder="None" /></SelectTrigger>
                <SelectContent>{bookings.map((b: any) => <SelectItem key={b.id} value={b.id}>{b.event_title}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label>Amount</Label><Input type="number" step="0.01" required value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Due date</Label><Input type="date" value={form.due_at} onChange={(e) => setForm({ ...form, due_at: e.target.value })} /></div>
            <div className="col-span-2 space-y-1.5"><Label>Status</Label>
              <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{["draft","sent","paid","overdue","void"].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="col-span-2 space-y-1.5"><Label>Notes</Label><Textarea rows={3} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
          </div>
        )}
      />
    </AppShell>
  );
}
