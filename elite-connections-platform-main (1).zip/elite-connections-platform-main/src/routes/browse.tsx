import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Sparkles, Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { SignedImage } from "@/components/SignedImage";

export const Route = createFileRoute("/browse")({
  head: () => ({
    meta: [
      { title: "Browse talent — Luxe Companions" },
      { name: "description", content: "Discover verified models, hosts and brand ambassadors available for booking." },
      { property: "og:title", content: "Browse talent — Luxe Companions" },
      { property: "og:description", content: "Discover verified models, hosts and brand ambassadors available for booking." },
    ],
  }),
  component: BrowsePage,
});

function BrowsePage() {
  const [q, setQ] = useState("");
  const [tier, setTier] = useState<string>("all");

  const { data: talent = [], isLoading } = useQuery({
    queryKey: ["browse-talent"],
    queryFn: async () => {
      const { data } = await supabase
        .from("talent")
        .select("id, stage_name, city, category, tier, avatar_url, bio")
        .eq("status", "active")
        .eq("verification_status", "verified")
        .order("created_at", { ascending: false });
      return data ?? [];
    },
  });

  const filtered = (talent as any[]).filter((t) => {
    if (tier !== "all" && t.tier !== tier) return false;
    if (q.trim()) {
      const s = q.toLowerCase();
      return [t.stage_name, t.city, t.category, t.bio].some((v) => v?.toLowerCase().includes(s));
    }
    return true;
  });

  return (
    <div className="min-h-screen">
      <header className="px-6 sm:px-8 py-6 flex items-center justify-between max-w-7xl mx-auto border-b border-border">
        <Link to="/" className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-[color:var(--gold)]" />
          <span className="font-display text-2xl gold-gradient">Luxe Companions</span>
        </Link>
        <Button asChild variant="outline"><Link to="/auth">Sign in</Link></Button>
      </header>

      <div className="max-w-7xl mx-auto px-6 sm:px-8 py-10">
        <h1 className="font-display text-4xl">Browse talent</h1>
        <p className="text-muted-foreground mt-1">All listings are identity-verified by our team.</p>

        <div className="mt-6 flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by name, city, category…" className="pl-9" />
          </div>
          <div className="flex gap-2">
            {["all", "signature", "premier", "standard"].map((t) => (
              <Button key={t} variant={tier === t ? "default" : "outline"} size="sm" onClick={() => setTier(t)} className="capitalize">
                {t}
              </Button>
            ))}
          </div>
        </div>

        <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {isLoading && <div className="col-span-full text-center text-muted-foreground py-12">Loading…</div>}
          {!isLoading && filtered.length === 0 && (
            <div className="col-span-full text-center text-muted-foreground py-12">No talent matches your filters.</div>
          )}
          {filtered.map((t: any) => (
            <Link key={t.id} to="/talent/$id" params={{ id: t.id }} className="luxe-card rounded-xl overflow-hidden group">
              <div className="aspect-[4/5] bg-secondary overflow-hidden">
                <SignedImage
                  bucket="avatars"
                  path={t.avatar_url}
                  alt={t.stage_name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  fallback={<div className="w-full h-full grid place-items-center text-muted-foreground"><Sparkles className="h-8 w-8" /></div>}
                />
              </div>
              <div className="p-4">
                <div className="flex items-center justify-between">
                  <div className="font-display text-lg">{t.stage_name}</div>
                  <Badge variant="outline" className="capitalize text-xs">{t.tier}</Badge>
                </div>
                <div className="text-xs text-muted-foreground mt-0.5">{t.category}{t.city ? ` · ${t.city}` : ""}</div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
