export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      booking_requests: {
        Row: {
          admin_note: string | null
          booking_id: string | null
          budget: number | null
          client_id: string | null
          created_at: string
          ends_at: string
          event_title: string
          id: string
          location: string | null
          message: string | null
          requester_user_id: string
          reviewed_at: string | null
          reviewed_by: string | null
          starts_at: string
          status: Database["public"]["Enums"]["booking_request_status"]
          talent_id: string
          updated_at: string
        }
        Insert: {
          admin_note?: string | null
          booking_id?: string | null
          budget?: number | null
          client_id?: string | null
          created_at?: string
          ends_at: string
          event_title: string
          id?: string
          location?: string | null
          message?: string | null
          requester_user_id: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          starts_at: string
          status?: Database["public"]["Enums"]["booking_request_status"]
          talent_id: string
          updated_at?: string
        }
        Update: {
          admin_note?: string | null
          booking_id?: string | null
          budget?: number | null
          client_id?: string | null
          created_at?: string
          ends_at?: string
          event_title?: string
          id?: string
          location?: string | null
          message?: string | null
          requester_user_id?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          starts_at?: string
          status?: Database["public"]["Enums"]["booking_request_status"]
          talent_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "booking_requests_booking_id_fkey"
            columns: ["booking_id"]
            isOneToOne: false
            referencedRelation: "bookings"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "booking_requests_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "booking_requests_talent_id_fkey"
            columns: ["talent_id"]
            isOneToOne: false
            referencedRelation: "talent"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "booking_requests_talent_id_fkey"
            columns: ["talent_id"]
            isOneToOne: false
            referencedRelation: "talent_public"
            referencedColumns: ["id"]
          },
        ]
      }
      bookings: {
        Row: {
          client_id: string
          commission_amount: number
          commission_rate: number
          created_at: string
          ends_at: string
          event_title: string
          gross_fee: number
          id: string
          location: string | null
          notes: string | null
          starts_at: string
          status: Database["public"]["Enums"]["booking_status"]
          talent_id: string
          talent_payout: number
          updated_at: string
        }
        Insert: {
          client_id: string
          commission_amount?: number
          commission_rate?: number
          created_at?: string
          ends_at: string
          event_title: string
          gross_fee?: number
          id?: string
          location?: string | null
          notes?: string | null
          starts_at: string
          status?: Database["public"]["Enums"]["booking_status"]
          talent_id: string
          talent_payout?: number
          updated_at?: string
        }
        Update: {
          client_id?: string
          commission_amount?: number
          commission_rate?: number
          created_at?: string
          ends_at?: string
          event_title?: string
          gross_fee?: number
          id?: string
          location?: string | null
          notes?: string | null
          starts_at?: string
          status?: Database["public"]["Enums"]["booking_status"]
          talent_id?: string
          talent_payout?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "bookings_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bookings_talent_id_fkey"
            columns: ["talent_id"]
            isOneToOne: false
            referencedRelation: "talent"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bookings_talent_id_fkey"
            columns: ["talent_id"]
            isOneToOne: false
            referencedRelation: "talent_public"
            referencedColumns: ["id"]
          },
        ]
      }
      clients: {
        Row: {
          city: string | null
          company: string | null
          created_at: string
          email: string | null
          full_name: string
          id: string
          notes: string | null
          phone: string | null
          profile_user_id: string | null
          tier: string | null
          updated_at: string
        }
        Insert: {
          city?: string | null
          company?: string | null
          created_at?: string
          email?: string | null
          full_name: string
          id?: string
          notes?: string | null
          phone?: string | null
          profile_user_id?: string | null
          tier?: string | null
          updated_at?: string
        }
        Update: {
          city?: string | null
          company?: string | null
          created_at?: string
          email?: string | null
          full_name?: string
          id?: string
          notes?: string | null
          phone?: string | null
          profile_user_id?: string | null
          tier?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      contracts: {
        Row: {
          body: string
          booking_id: string
          created_at: string
          id: string
          sent_at: string | null
          signed_at: string | null
          signer_name: string | null
          status: Database["public"]["Enums"]["contract_status"]
          title: string
          updated_at: string
        }
        Insert: {
          body?: string
          booking_id: string
          created_at?: string
          id?: string
          sent_at?: string | null
          signed_at?: string | null
          signer_name?: string | null
          status?: Database["public"]["Enums"]["contract_status"]
          title: string
          updated_at?: string
        }
        Update: {
          body?: string
          booking_id?: string
          created_at?: string
          id?: string
          sent_at?: string | null
          signed_at?: string | null
          signer_name?: string | null
          status?: Database["public"]["Enums"]["contract_status"]
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "contracts_booking_id_fkey"
            columns: ["booking_id"]
            isOneToOne: false
            referencedRelation: "bookings"
            referencedColumns: ["id"]
          },
        ]
      }
      dispute_evidence: {
        Row: {
          created_at: string
          dispute_id: string
          file_name: string
          file_size: number | null
          file_type: string | null
          id: string
          note: string | null
          storage_path: string
          uploader_id: string
        }
        Insert: {
          created_at?: string
          dispute_id: string
          file_name: string
          file_size?: number | null
          file_type?: string | null
          id?: string
          note?: string | null
          storage_path: string
          uploader_id: string
        }
        Update: {
          created_at?: string
          dispute_id?: string
          file_name?: string
          file_size?: number | null
          file_type?: string | null
          id?: string
          note?: string | null
          storage_path?: string
          uploader_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "dispute_evidence_dispute_id_fkey"
            columns: ["dispute_id"]
            isOneToOne: false
            referencedRelation: "disputes"
            referencedColumns: ["id"]
          },
        ]
      }
      disputes: {
        Row: {
          booking_id: string
          category: string
          created_at: string
          id: string
          opened_by: string
          reason: string
          resolution: string | null
          resolved_at: string | null
          resolved_by: string | null
          status: Database["public"]["Enums"]["dispute_status"]
          updated_at: string
        }
        Insert: {
          booking_id: string
          category: string
          created_at?: string
          id?: string
          opened_by: string
          reason: string
          resolution?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          status?: Database["public"]["Enums"]["dispute_status"]
          updated_at?: string
        }
        Update: {
          booking_id?: string
          category?: string
          created_at?: string
          id?: string
          opened_by?: string
          reason?: string
          resolution?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          status?: Database["public"]["Enums"]["dispute_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "disputes_booking_id_fkey"
            columns: ["booking_id"]
            isOneToOne: false
            referencedRelation: "bookings"
            referencedColumns: ["id"]
          },
        ]
      }
      invoices: {
        Row: {
          amount: number
          booking_id: string | null
          client_id: string
          created_at: string
          due_at: string | null
          id: string
          invoice_number: string
          issued_at: string
          notes: string | null
          paid_at: string | null
          status: Database["public"]["Enums"]["invoice_status"]
          updated_at: string
        }
        Insert: {
          amount?: number
          booking_id?: string | null
          client_id: string
          created_at?: string
          due_at?: string | null
          id?: string
          invoice_number?: string
          issued_at?: string
          notes?: string | null
          paid_at?: string | null
          status?: Database["public"]["Enums"]["invoice_status"]
          updated_at?: string
        }
        Update: {
          amount?: number
          booking_id?: string | null
          client_id?: string
          created_at?: string
          due_at?: string | null
          id?: string
          invoice_number?: string
          issued_at?: string
          notes?: string | null
          paid_at?: string | null
          status?: Database["public"]["Enums"]["invoice_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "invoices_booking_id_fkey"
            columns: ["booking_id"]
            isOneToOne: false
            referencedRelation: "bookings"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoices_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      messages: {
        Row: {
          attachment_name: string | null
          attachment_path: string | null
          attachment_type: string | null
          body: string | null
          booking_id: string
          created_at: string
          id: string
          sender_id: string
        }
        Insert: {
          attachment_name?: string | null
          attachment_path?: string | null
          attachment_type?: string | null
          body?: string | null
          booking_id: string
          created_at?: string
          id?: string
          sender_id: string
        }
        Update: {
          attachment_name?: string | null
          attachment_path?: string | null
          attachment_type?: string | null
          body?: string | null
          booking_id?: string
          created_at?: string
          id?: string
          sender_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "messages_booking_id_fkey"
            columns: ["booking_id"]
            isOneToOne: false
            referencedRelation: "bookings"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          body: string | null
          created_at: string
          id: string
          link: string | null
          read_at: string | null
          title: string
          type: string
          user_id: string
        }
        Insert: {
          body?: string | null
          created_at?: string
          id?: string
          link?: string | null
          read_at?: string | null
          title: string
          type: string
          user_id: string
        }
        Update: {
          body?: string | null
          created_at?: string
          id?: string
          link?: string | null
          read_at?: string | null
          title?: string
          type?: string
          user_id?: string
        }
        Relationships: []
      }
      payouts: {
        Row: {
          amount: number
          booking_id: string | null
          created_at: string
          id: string
          method: string | null
          notes: string | null
          paid_at: string | null
          reference: string | null
          status: Database["public"]["Enums"]["payout_status"]
          talent_id: string
          updated_at: string
        }
        Insert: {
          amount?: number
          booking_id?: string | null
          created_at?: string
          id?: string
          method?: string | null
          notes?: string | null
          paid_at?: string | null
          reference?: string | null
          status?: Database["public"]["Enums"]["payout_status"]
          talent_id: string
          updated_at?: string
        }
        Update: {
          amount?: number
          booking_id?: string | null
          created_at?: string
          id?: string
          method?: string | null
          notes?: string | null
          paid_at?: string | null
          reference?: string | null
          status?: Database["public"]["Enums"]["payout_status"]
          talent_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "payouts_booking_id_fkey"
            columns: ["booking_id"]
            isOneToOne: false
            referencedRelation: "bookings"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payouts_talent_id_fkey"
            columns: ["talent_id"]
            isOneToOne: false
            referencedRelation: "talent"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payouts_talent_id_fkey"
            columns: ["talent_id"]
            isOneToOne: false
            referencedRelation: "talent_public"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          full_name: string | null
          id: string
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          full_name?: string | null
          id: string
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          full_name?: string | null
          id?: string
          updated_at?: string
        }
        Relationships: []
      }
      review_moderation_log: {
        Row: {
          created_at: string
          id: string
          moderator_id: string | null
          new_status: string
          note: string | null
          prev_status: string | null
          review_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          moderator_id?: string | null
          new_status: string
          note?: string | null
          prev_status?: string | null
          review_id: string
        }
        Update: {
          created_at?: string
          id?: string
          moderator_id?: string | null
          new_status?: string
          note?: string | null
          prev_status?: string | null
          review_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "review_moderation_log_review_id_fkey"
            columns: ["review_id"]
            isOneToOne: false
            referencedRelation: "reviews"
            referencedColumns: ["id"]
          },
        ]
      }
      reviews: {
        Row: {
          body: string | null
          booking_id: string
          client_id: string
          created_at: string
          id: string
          is_published: boolean
          moderated_at: string | null
          moderated_by: string | null
          moderation_status: Database["public"]["Enums"]["review_status"]
          moderator_note: string | null
          rating: number
          talent_id: string
          updated_at: string
        }
        Insert: {
          body?: string | null
          booking_id: string
          client_id: string
          created_at?: string
          id?: string
          is_published?: boolean
          moderated_at?: string | null
          moderated_by?: string | null
          moderation_status?: Database["public"]["Enums"]["review_status"]
          moderator_note?: string | null
          rating: number
          talent_id: string
          updated_at?: string
        }
        Update: {
          body?: string | null
          booking_id?: string
          client_id?: string
          created_at?: string
          id?: string
          is_published?: boolean
          moderated_at?: string | null
          moderated_by?: string | null
          moderation_status?: Database["public"]["Enums"]["review_status"]
          moderator_note?: string | null
          rating?: number
          talent_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "reviews_booking_id_fkey"
            columns: ["booking_id"]
            isOneToOne: true
            referencedRelation: "bookings"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reviews_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reviews_talent_id_fkey"
            columns: ["talent_id"]
            isOneToOne: false
            referencedRelation: "talent"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reviews_talent_id_fkey"
            columns: ["talent_id"]
            isOneToOne: false
            referencedRelation: "talent_public"
            referencedColumns: ["id"]
          },
        ]
      }
      talent: {
        Row: {
          avatar_url: string | null
          bio: string | null
          category: string | null
          city: string | null
          created_at: string
          day_rate: number | null
          email: string | null
          gender: Database["public"]["Enums"]["talent_gender"]
          height_cm: number | null
          hourly_rate: number | null
          id: string
          id_document_back_url: string | null
          id_document_url: string | null
          languages: string[] | null
          legal_name: string | null
          phone: string | null
          profile_user_id: string | null
          stage_name: string
          status: Database["public"]["Enums"]["talent_status"]
          tier: Database["public"]["Enums"]["talent_tier"]
          updated_at: string
          verification_note: string | null
          verification_rejection_reason: string | null
          verification_reviewed_at: string | null
          verification_reviewed_by: string | null
          verification_status: Database["public"]["Enums"]["verification_status"]
          verification_submitted_at: string | null
        }
        Insert: {
          avatar_url?: string | null
          bio?: string | null
          category?: string | null
          city?: string | null
          created_at?: string
          day_rate?: number | null
          email?: string | null
          gender?: Database["public"]["Enums"]["talent_gender"]
          height_cm?: number | null
          hourly_rate?: number | null
          id?: string
          id_document_back_url?: string | null
          id_document_url?: string | null
          languages?: string[] | null
          legal_name?: string | null
          phone?: string | null
          profile_user_id?: string | null
          stage_name: string
          status?: Database["public"]["Enums"]["talent_status"]
          tier?: Database["public"]["Enums"]["talent_tier"]
          updated_at?: string
          verification_note?: string | null
          verification_rejection_reason?: string | null
          verification_reviewed_at?: string | null
          verification_reviewed_by?: string | null
          verification_status?: Database["public"]["Enums"]["verification_status"]
          verification_submitted_at?: string | null
        }
        Update: {
          avatar_url?: string | null
          bio?: string | null
          category?: string | null
          city?: string | null
          created_at?: string
          day_rate?: number | null
          email?: string | null
          gender?: Database["public"]["Enums"]["talent_gender"]
          height_cm?: number | null
          hourly_rate?: number | null
          id?: string
          id_document_back_url?: string | null
          id_document_url?: string | null
          languages?: string[] | null
          legal_name?: string | null
          phone?: string | null
          profile_user_id?: string | null
          stage_name?: string
          status?: Database["public"]["Enums"]["talent_status"]
          tier?: Database["public"]["Enums"]["talent_tier"]
          updated_at?: string
          verification_note?: string | null
          verification_rejection_reason?: string | null
          verification_reviewed_at?: string | null
          verification_reviewed_by?: string | null
          verification_status?: Database["public"]["Enums"]["verification_status"]
          verification_submitted_at?: string | null
        }
        Relationships: []
      }
      talent_media: {
        Row: {
          caption: string | null
          created_at: string
          id: string
          is_public: boolean
          sort_order: number
          storage_path: string | null
          talent_id: string
          url: string
        }
        Insert: {
          caption?: string | null
          created_at?: string
          id?: string
          is_public?: boolean
          sort_order?: number
          storage_path?: string | null
          talent_id: string
          url: string
        }
        Update: {
          caption?: string | null
          created_at?: string
          id?: string
          is_public?: boolean
          sort_order?: number
          storage_path?: string | null
          talent_id?: string
          url?: string
        }
        Relationships: [
          {
            foreignKeyName: "talent_media_talent_id_fkey"
            columns: ["talent_id"]
            isOneToOne: false
            referencedRelation: "talent"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "talent_media_talent_id_fkey"
            columns: ["talent_id"]
            isOneToOne: false
            referencedRelation: "talent_public"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      talent_public: {
        Row: {
          avatar_url: string | null
          bio: string | null
          category: string | null
          city: string | null
          created_at: string | null
          day_rate: number | null
          gender: Database["public"]["Enums"]["talent_gender"] | null
          height_cm: number | null
          hourly_rate: number | null
          id: string | null
          languages: string[] | null
          stage_name: string | null
          status: Database["public"]["Enums"]["talent_status"] | null
          tier: Database["public"]["Enums"]["talent_tier"] | null
          verification_status:
            | Database["public"]["Enums"]["verification_status"]
            | null
        }
        Insert: {
          avatar_url?: string | null
          bio?: string | null
          category?: string | null
          city?: string | null
          created_at?: string | null
          day_rate?: number | null
          gender?: Database["public"]["Enums"]["talent_gender"] | null
          height_cm?: number | null
          hourly_rate?: number | null
          id?: string | null
          languages?: string[] | null
          stage_name?: string | null
          status?: Database["public"]["Enums"]["talent_status"] | null
          tier?: Database["public"]["Enums"]["talent_tier"] | null
          verification_status?:
            | Database["public"]["Enums"]["verification_status"]
            | null
        }
        Update: {
          avatar_url?: string | null
          bio?: string | null
          category?: string | null
          city?: string | null
          created_at?: string | null
          day_rate?: number | null
          gender?: Database["public"]["Enums"]["talent_gender"] | null
          height_cm?: number | null
          hourly_rate?: number | null
          id?: string | null
          languages?: string[] | null
          stage_name?: string | null
          status?: Database["public"]["Enums"]["talent_status"] | null
          tier?: Database["public"]["Enums"]["talent_tier"] | null
          verification_status?:
            | Database["public"]["Enums"]["verification_status"]
            | null
        }
        Relationships: []
      }
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_client_owner: {
        Args: { _client_id: string; _user_id: string }
        Returns: boolean
      }
      is_talent_owner: {
        Args: { _talent_id: string; _user_id: string }
        Returns: boolean
      }
      notify_user: {
        Args: {
          _body: string
          _link: string
          _title: string
          _type: string
          _user_id: string
        }
        Returns: undefined
      }
    }
    Enums: {
      app_role: "admin" | "agent" | "talent" | "client"
      booking_request_status:
        | "pending"
        | "approved"
        | "rejected"
        | "cancelled"
        | "converted"
      booking_status:
        | "inquiry"
        | "confirmed"
        | "in_progress"
        | "completed"
        | "cancelled"
      contract_status: "draft" | "sent" | "signed" | "cancelled"
      dispute_status: "open" | "under_review" | "resolved" | "rejected"
      invoice_status: "draft" | "sent" | "paid" | "overdue" | "void"
      payout_status: "pending" | "processing" | "paid" | "failed"
      review_status: "pending" | "approved" | "rejected"
      talent_gender: "female" | "male" | "non_binary" | "other"
      talent_status: "active" | "on_hold" | "inactive"
      talent_tier: "signature" | "premier" | "standard"
      verification_status: "unsubmitted" | "submitted" | "verified" | "rejected"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "agent", "talent", "client"],
      booking_request_status: [
        "pending",
        "approved",
        "rejected",
        "cancelled",
        "converted",
      ],
      booking_status: [
        "inquiry",
        "confirmed",
        "in_progress",
        "completed",
        "cancelled",
      ],
      contract_status: ["draft", "sent", "signed", "cancelled"],
      dispute_status: ["open", "under_review", "resolved", "rejected"],
      invoice_status: ["draft", "sent", "paid", "overdue", "void"],
      payout_status: ["pending", "processing", "paid", "failed"],
      review_status: ["pending", "approved", "rejected"],
      talent_gender: ["female", "male", "non_binary", "other"],
      talent_status: ["active", "on_hold", "inactive"],
      talent_tier: ["signature", "premier", "standard"],
      verification_status: ["unsubmitted", "submitted", "verified", "rejected"],
    },
  },
} as const
