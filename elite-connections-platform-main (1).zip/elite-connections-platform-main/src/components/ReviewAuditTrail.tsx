import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { History } from "lucide-react";
import { timeAgo } from "@/lib/format";

type LogEntry = {
  id: string; review_id: string; moderator_id: string | null;
  prev_status: string | null; new_status: string; note: string | null; created_at: string;
};

export function ReviewAuditTrail({ reviewId }: { reviewId: string }) {
  const { data: items = [] } = useQuery({
    queryKey: ["review-audit", reviewId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("review_moderation_log" as any)
        .select("id, review_id, moderator_id, prev_status, new_status, note, created_at")
        .eq("review_id", reviewId)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return (data ?? []) as unknown as LogEntry[];
    },
  });

  if (items.length === 0) return null;

  return (
    <div className="mt-3 border-t border-border/60 pt-3">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground flex items-center gap-1 mb-1.5">
        <History className="h-3 w-3" /> Audit trail
      </div>
      <ol className="space-y-1">
        {items.map((e) => (
          <li key={e.id} className="text-xs text-muted-foreground flex items-start gap-2">
            <span className="mt-1 h-1 w-1 rounded-full bg-[color:var(--gold)] shrink-0" />
            <span>
              <span className="text-foreground">
                {e.prev_status ? <>{e.prev_status} → <b className="text-foreground">{e.new_status}</b></> : <b>created</b>}
              </span>
              {e.note && <> · "{e.note}"</>}
              {e.moderator_id && <> · by {e.moderator_id.slice(0, 8)}</>}
              {" · "}{timeAgo(e.created_at)}
            </span>
          </li>
        ))}
      </ol>
    </div>
  );
}
