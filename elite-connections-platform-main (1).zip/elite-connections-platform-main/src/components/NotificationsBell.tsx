import { useEffect, useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Bell, BellOff, Calendar, MessageCircle, ShieldAlert, Star,
  CheckCheck, ArrowRight, Inbox,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/use-auth";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { timeAgo } from "@/lib/format";
import { toast } from "sonner";

type Notif = {
  id: string; type: string; title: string; body: string | null;
  link: string | null; read_at: string | null; created_at: string;
};

function iconFor(type: string) {
  if (type.startsWith("booking")) return Calendar;
  if (type.startsWith("message")) return MessageCircle;
  if (type.startsWith("dispute")) return ShieldAlert;
  if (type.startsWith("review")) return Star;
  return Bell;
}

function bucketLabel(iso: string): string {
  const d = new Date(iso);
  const today = new Date();
  const yesterday = new Date(); yesterday.setDate(today.getDate() - 1);
  if (d.toDateString() === today.toDateString()) return "Today";
  if (d.toDateString() === yesterday.toDateString()) return "Yesterday";
  const sevenAgo = new Date(); sevenAgo.setDate(today.getDate() - 7);
  if (d >= sevenAgo) return "This week";
  return "Earlier";
}

export function NotificationsBell() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [filter, setFilter] = useState<"all" | "unread">("all");

  const { data: items = [] } = useQuery({
    queryKey: ["notifications", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase
        .from("notifications" as any)
        .select("id, type, title, body, link, read_at, created_at")
        .order("created_at", { ascending: false })
        .limit(50);
      return (data ?? []) as unknown as Notif[];
    },
  });

  useEffect(() => {
    if (!user) return;
    const channel = supabase
      .channel(`notif:${user.id}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "notifications", filter: `user_id=eq.${user.id}` },
        () => qc.invalidateQueries({ queryKey: ["notifications", user.id] }),
      )
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user, qc]);

  const unread = items.filter((n) => !n.read_at).length;
  const visible = filter === "unread" ? items.filter((n) => !n.read_at) : items;

  const grouped = useMemo(() => {
    const out: Record<string, Notif[]> = {};
    for (const n of visible) {
      const k = bucketLabel(n.created_at);
      (out[k] ??= []).push(n);
    }
    return out;
  }, [visible]);

  async function markAllRead() {
    if (!user || unread === 0) return;
    const { error } = await supabase
      .from("notifications" as any)
      .update({ read_at: new Date().toISOString() })
      .is("read_at", null);
    if (error) { toast.error(error.message); return; }
    qc.invalidateQueries({ queryKey: ["notifications", user.id] });
  }

  async function markOneRead(id: string) {
    await supabase.from("notifications" as any).update({ read_at: new Date().toISOString() }).eq("id", id);
    qc.invalidateQueries({ queryKey: ["notifications", user?.id] });
  }

  if (!user) return null;

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative" aria-label="Notifications">
          <Bell className="h-5 w-5" />
          {unread > 0 && (
            <span className="absolute -top-0.5 -right-0.5 h-4 min-w-4 px-1 rounded-full bg-[color:var(--gold)] text-[10px] font-medium text-background flex items-center justify-center shadow-[0_0_0_2px_hsl(var(--background))]">
              {unread > 9 ? "9+" : unread}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-[360px] p-0 overflow-hidden">
        <div className="px-3 py-2.5 border-b border-border flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="font-medium text-sm">Notifications</div>
            {unread > 0 && (
              <span className="text-[10px] uppercase tracking-wider px-1.5 py-0.5 rounded bg-[color:var(--gold)]/15 text-[color:var(--gold)]">
                {unread} new
              </span>
            )}
          </div>
          <button
            onClick={markAllRead}
            disabled={unread === 0}
            className="text-xs text-muted-foreground hover:text-foreground disabled:opacity-40 inline-flex items-center gap-1"
          >
            <CheckCheck className="h-3.5 w-3.5" /> Mark all
          </button>
        </div>
        <div className="px-3 pt-2 pb-1 flex gap-1 border-b border-border">
          {(["all", "unread"] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                "text-xs px-2 py-1 rounded-md capitalize transition-colors",
                filter === f ? "bg-secondary text-foreground" : "text-muted-foreground hover:text-foreground",
              )}
            >
              {f}
            </button>
          ))}
        </div>
        <div className="max-h-[420px] overflow-y-auto">
          {visible.length === 0 && (
            <div className="px-6 py-12 text-center text-sm text-muted-foreground">
              {filter === "unread" ? (
                <><BellOff className="h-6 w-6 mx-auto mb-2 opacity-60" />You're all caught up.</>
              ) : (
                <><Inbox className="h-6 w-6 mx-auto mb-2 opacity-60" />No notifications yet.</>
              )}
            </div>
          )}
          {Object.entries(grouped).map(([bucket, list]) => (
            <div key={bucket}>
              <div className="px-3 pt-3 pb-1 text-[10px] uppercase tracking-wider text-muted-foreground">{bucket}</div>
              <div className="divide-y divide-border/60">
                {list.map((n) => {
                  const Icon = iconFor(n.type);
                  const Inner = (
                    <div className={cn(
                      "group px-3 py-2.5 flex gap-3 hover:bg-accent/40 transition-colors",
                      !n.read_at && "bg-accent/15",
                    )}>
                      <div className={cn(
                        "mt-0.5 h-8 w-8 rounded-full flex items-center justify-center shrink-0 border",
                        !n.read_at
                          ? "bg-[color:var(--gold)]/10 border-[color:var(--gold)]/40 text-[color:var(--gold)]"
                          : "bg-secondary border-border text-muted-foreground",
                      )}>
                        <Icon className="h-4 w-4" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-start justify-between gap-2">
                          <div className="text-sm font-medium leading-snug">{n.title}</div>
                          {!n.read_at && <span className="mt-1 h-1.5 w-1.5 rounded-full bg-[color:var(--gold)] shrink-0" />}
                        </div>
                        {n.body && <div className="text-xs text-muted-foreground mt-0.5 truncate">{n.body}</div>}
                        <div className="text-[10px] text-muted-foreground mt-1 flex items-center justify-between">
                          <span>{timeAgo(n.created_at)}</span>
                          {n.link && (
                            <span className="opacity-0 group-hover:opacity-100 transition-opacity inline-flex items-center gap-0.5 text-[color:var(--gold)]">
                              Open <ArrowRight className="h-3 w-3" />
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                  return n.link ? (
                    <Link
                      key={n.id}
                      to={n.link}
                      onClick={() => { setOpen(false); if (!n.read_at) markOneRead(n.id); }}
                      className="block"
                    >
                      {Inner}
                    </Link>
                  ) : (
                    <button
                      key={n.id}
                      onClick={() => !n.read_at && markOneRead(n.id)}
                      className="block w-full text-left"
                    >
                      {Inner}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </PopoverContent>
    </Popover>
  );
}
