import { useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Paperclip, Trash2, FileIcon, ImageIcon, Download } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/use-auth";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { formatBytes, sanitizeFilename, timeAgo } from "@/lib/format";

const MAX_BYTES = 15 * 1024 * 1024;
const ALLOWED = [
  "image/png", "image/jpeg", "image/webp", "image/gif",
  "application/pdf", "text/plain",
];

type Evidence = {
  id: string; dispute_id: string; uploader_id: string;
  storage_path: string; file_name: string; file_type: string | null;
  file_size: number | null; note: string | null; created_at: string;
};

export function DisputeEvidence({ disputeId }: { disputeId: string }) {
  const { user } = useAuth();
  const qc = useQueryClient();
  const fileRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [note, setNote] = useState("");

  const { data: items = [] } = useQuery({
    queryKey: ["dispute-evidence", disputeId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("dispute_evidence" as any)
        .select("id, dispute_id, uploader_id, storage_path, file_name, file_type, file_size, note, created_at")
        .eq("dispute_id", disputeId)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as Evidence[];
    },
  });

  const upload = useMutation({
    mutationFn: async () => {
      if (!user) throw new Error("Sign in required");
      if (!file && !note.trim()) throw new Error("Add a note or attach a file");
      let storage_path = ""; let file_name = ""; let file_type: string | null = null; let file_size: number | null = null;
      if (file) {
        if (file.size > MAX_BYTES) throw new Error("File exceeds 15 MB");
        if (file.type && !ALLOWED.includes(file.type)) throw new Error("Unsupported file type");
        const safe = sanitizeFilename(file.name);
        const ext = safe.includes(".") ? safe.split(".").pop() : "bin";
        storage_path = `${disputeId}/${crypto.randomUUID()}.${ext}`;
        const { error: ue } = await supabase.storage.from("dispute-evidence").upload(storage_path, file, {
          contentType: file.type || "application/octet-stream", upsert: false,
        });
        if (ue) throw ue;
        file_name = safe; file_type = file.type || null; file_size = file.size;
      } else {
        file_name = "(note)";
      }
      const { error } = await supabase.from("dispute_evidence" as any).insert({
        dispute_id: disputeId, uploader_id: user.id,
        storage_path: storage_path || `note/${crypto.randomUUID()}`,
        file_name, file_type, file_size, note: note.trim() || null,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Evidence added");
      setFile(null); setNote("");
      if (fileRef.current) fileRef.current.value = "";
      qc.invalidateQueries({ queryKey: ["dispute-evidence", disputeId] });
    },
    onError: (e: any) => toast.error(e.message ?? "Failed"),
  });

  const remove = useMutation({
    mutationFn: async (ev: Evidence) => {
      if (ev.storage_path && !ev.storage_path.startsWith("note/")) {
        await supabase.storage.from("dispute-evidence").remove([ev.storage_path]);
      }
      const { error } = await supabase.from("dispute_evidence" as any).delete().eq("id", ev.id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Removed");
      qc.invalidateQueries({ queryKey: ["dispute-evidence", disputeId] });
    },
    onError: (e: any) => toast.error(e.message ?? "Failed"),
  });

  async function openSigned(path: string) {
    const { data } = await supabase.storage.from("dispute-evidence").createSignedUrl(path, 60);
    if (data?.signedUrl) window.open(data.signedUrl, "_blank");
  }

  return (
    <div className="mt-3 border-t border-border/60 pt-3 space-y-3">
      <div className="text-xs uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
        <Paperclip className="h-3.5 w-3.5" /> Evidence ({items.length})
      </div>
      <div className="space-y-1.5">
        {items.length === 0 && <div className="text-xs text-muted-foreground italic">No evidence attached yet.</div>}
        {items.map((ev) => {
          const isImage = ev.file_type?.startsWith("image/");
          const isNote = ev.storage_path.startsWith("note/");
          return (
            <div key={ev.id} className="flex items-start gap-2 text-sm bg-secondary/50 rounded-md px-2.5 py-2">
              <div className="mt-0.5 text-muted-foreground">
                {isImage ? <ImageIcon className="h-4 w-4" /> : <FileIcon className="h-4 w-4" />}
              </div>
              <div className="flex-1 min-w-0">
                {!isNote && (
                  <button
                    onClick={() => openSigned(ev.storage_path)}
                    className="text-sm font-medium hover:underline truncate text-left block w-full"
                  >
                    {ev.file_name}
                  </button>
                )}
                <div className="text-[11px] text-muted-foreground">
                  {!isNote && ev.file_size != null && <>{formatBytes(ev.file_size)} · </>}
                  {timeAgo(ev.created_at)}
                </div>
                {ev.note && <div className="text-sm mt-1 whitespace-pre-wrap">{ev.note}</div>}
              </div>
              {!isNote && (
                <button onClick={() => openSigned(ev.storage_path)} className="text-muted-foreground hover:text-foreground" title="Download">
                  <Download className="h-3.5 w-3.5" />
                </button>
              )}
              {ev.uploader_id === user?.id && (
                <button onClick={() => remove.mutate(ev)} className="text-muted-foreground hover:text-destructive" title="Remove">
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
          );
        })}
      </div>
      <div className="space-y-2">
        <Textarea rows={2} placeholder="Add a note (optional)" value={note} onChange={(e) => setNote(e.target.value)} />
        <div className="flex items-center gap-2">
          <Input
            ref={fileRef}
            type="file"
            accept={ALLOWED.join(",")}
            className="flex-1 text-xs"
            onChange={(e) => {
              const f = e.target.files?.[0] ?? null;
              if (!f) return setFile(null);
              if (f.size > MAX_BYTES) { toast.error("File exceeds 15 MB"); e.target.value = ""; return; }
              if (f.type && !ALLOWED.includes(f.type)) { toast.error("Unsupported file type"); e.target.value = ""; return; }
              setFile(f);
            }}
          />
          <Button size="sm" onClick={() => upload.mutate()} disabled={upload.isPending || (!file && !note.trim())}>
            {upload.isPending ? "Saving…" : "Attach"}
          </Button>
        </div>
        {file && <div className="text-[11px] text-muted-foreground">{file.name} · {formatBytes(file.size)}</div>}
      </div>
    </div>
  );
}
