import { Link, useLocation, useNavigate } from "@tanstack/react-router";
import {
  LayoutDashboard, Users, UserSquare2, CalendarDays, FileSignature, Receipt, Wallet,
  LogOut, Sparkles, Menu, X, ShieldCheck, ShieldAlert, Inbox, User as UserIcon, Search, Star,
  MessagesSquare,
} from "lucide-react";
import { useState, type ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { useUserRole, isStaff, type AppRole } from "@/lib/use-auth";
import { NotificationsBell } from "@/components/NotificationsBell";

type Item = { to: string; label: string; icon: any };

const NAV_STAFF: Item[] = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/roster", label: "Talent", icon: Users },
  { to: "/clients", label: "Clients", icon: UserSquare2 },
  { to: "/bookings", label: "Bookings", icon: CalendarDays },
  { to: "/requests", label: "Requests", icon: Inbox },
  { to: "/verifications", label: "Verifications", icon: ShieldCheck },
  { to: "/reviews", label: "Reviews", icon: Star },
  { to: "/disputes", label: "Disputes", icon: ShieldAlert },
  { to: "/contracts", label: "Contracts", icon: FileSignature },
  { to: "/invoices", label: "Invoices", icon: Receipt },
  { to: "/payouts", label: "Payouts", icon: Wallet },
];

const NAV_ADMIN_EXTRA: Item[] = [
  { to: "/team", label: "Team", icon: ShieldCheck },
];

const NAV_TALENT: Item[] = [
  { to: "/dashboard", label: "Overview", icon: LayoutDashboard },
  { to: "/my-profile", label: "My profile", icon: UserIcon },
  { to: "/my-bookings", label: "My bookings", icon: CalendarDays },
  { to: "/disputes", label: "Disputes", icon: ShieldAlert },
];

const NAV_CLIENT: Item[] = [
  { to: "/dashboard", label: "Overview", icon: LayoutDashboard },
  { to: "/browse", label: "Browse talent", icon: Search },
  { to: "/my-bookings", label: "My bookings", icon: CalendarDays },
  { to: "/disputes", label: "Disputes", icon: ShieldAlert },
];


function navFor(role: AppRole | null | undefined): Item[] {
  if (role === "admin") return [...NAV_STAFF, ...NAV_ADMIN_EXTRA];
  if (isStaff(role)) return NAV_STAFF;
  if (role === "talent") return NAV_TALENT;
  return NAV_CLIENT;
}

function roleLabel(role: AppRole | null | undefined) {
  if (role === "admin") return "Administrator";
  if (role === "agent") return "Agency Manager";
  if (role === "talent") return "Talent";
  if (role === "client") return "Client";
  return "—";
}

export function AppShell({ title, actions, children }: { title: string; actions?: ReactNode; children: ReactNode }) {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);
  const { data: role } = useUserRole();
  const items = navFor(role);

  const signOut = async () => {
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  };

  const NavList = (
    <nav className="flex-1 px-3 py-4 space-y-1">
      {items.map(({ to, label, icon: Icon }) => {
        const active = pathname === to || pathname.startsWith(to + "/");
        return (
          <Link
            key={to}
            to={to}
            onClick={() => setMobileOpen(false)}
            className={cn(
              "flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors",
              active
                ? "bg-sidebar-accent text-[color:var(--gold)]"
                : "text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
            )}
          >
            <Icon className="h-4 w-4" />
            {label}
          </Link>
        );
      })}
    </nav>
  );

  const Brand = (
    <div className="px-6 py-6 border-b border-sidebar-border flex-1">
      <div className="flex items-center gap-2">
        <Sparkles className="h-5 w-5 text-[color:var(--gold)]" />
        <div className="min-w-0">
          <div className="font-display text-xl gold-gradient leading-tight">Luxe</div>
          <div className="text-[10px] tracking-[0.25em] uppercase text-muted-foreground truncate">
            Companions
          </div>
        </div>
      </div>
      <Badge variant="outline" className="mt-3 text-[10px] uppercase tracking-wider">
        {roleLabel(role)}
      </Badge>
    </div>
  );

  const SignOut = (
    <div className="p-3 border-t border-sidebar-border">
      <Button variant="ghost" size="sm" className="w-full justify-start" onClick={signOut}>
        <LogOut className="h-4 w-4 mr-2" /> Sign out
      </Button>
    </div>
  );

  return (
    <div className="min-h-screen flex bg-background">
      <aside className="hidden lg:flex w-64 shrink-0 border-r border-sidebar-border bg-sidebar flex-col">
        {Brand}
        {NavList}
        {SignOut}
      </aside>

      {mobileOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div className="absolute inset-0 bg-black/60" onClick={() => setMobileOpen(false)} />
          <aside className="relative w-64 bg-sidebar border-r border-sidebar-border flex flex-col">
            <div className="flex items-start">
              {Brand}
              <Button variant="ghost" size="icon" className="m-2" onClick={() => setMobileOpen(false)} aria-label="Close menu">
                <X className="h-4 w-4" />
              </Button>
            </div>
            {NavList}
            {SignOut}
          </aside>
        </div>
      )}

      <main className="flex-1 flex flex-col min-w-0">
        <header className="h-16 border-b border-border px-4 sm:px-8 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 min-w-0">
            <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setMobileOpen(true)} aria-label="Open menu">
              <Menu className="h-5 w-5" />
            </Button>
            <h1 className="font-display text-xl sm:text-2xl truncate">{title}</h1>
          </div>
          <div className="flex items-center gap-2"><NotificationsBell />{actions}</div>
        </header>
        <div className="flex-1 p-4 sm:p-8 overflow-auto">{children}</div>
      </main>
    </div>
  );
}
