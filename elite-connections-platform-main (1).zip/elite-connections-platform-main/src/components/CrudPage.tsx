import { useMemo, useState, type ReactNode } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Plus, Trash2, Pencil, Search, Download } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { toast } from "sonner";

type Column = { key: string; label: string; render?: (row: any) => ReactNode; searchable?: boolean };

export function CrudPage<T extends { id: string }>({
  table,
  title,
  columns,
  emptyText,
  defaultRow,
  formFields,
  orderBy = "created_at",
  select = "*",
  rowKey,
  searchKeys,
}: {
  table: string;
  title: string;
  columns: Column[];
  emptyText: string;
  defaultRow: Record<string, any>;
  formFields: ReactNode | ((state: Record<string, any>, setState: (s: Record<string, any>) => void) => ReactNode);
  orderBy?: string;
  select?: string;
  rowKey?: (row: any) => string;
  searchKeys?: string[];
}) {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any | null>(null);
  const [form, setForm] = useState<Record<string, any>>(defaultRow);
  const [search, setSearch] = useState("");

  const { data: rows = [], isLoading } = useQuery({
    queryKey: [table],
    queryFn: async () => {
      const { data, error } = await supabase.from(table as any).select(select).order(orderBy, { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  const cleanPayload = (payload: Record<string, any>) => {
    const out: Record<string, any> = {};
    for (const [k, v] of Object.entries(payload)) {
      if (v === "" || v === undefined) continue;
      out[k] = v;
    }
    return out;
  };

  const save = useMutation({
    mutationFn: async (payload: Record<string, any>) => {
      const clean = cleanPayload(payload);
      if (editing?.id) {
        const { error } = await supabase.from(table as any).update(clean).eq("id", editing.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from(table as any).insert(clean);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      toast.success(editing ? `${title} updated` : `${title} created`);
      qc.invalidateQueries({ queryKey: [table] });
      closeDialog();
    },
    onError: (e: any) => toast.error(e.message ?? "Failed"),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from(table as any).delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Deleted");
      qc.invalidateQueries({ queryKey: [table] });
    },
    onError: (e: any) => toast.error(e.message ?? "Failed"),
  });

  function openCreate() {
    setEditing(null);
    setForm(defaultRow);
    setOpen(true);
  }

  function openEdit(row: any) {
    setEditing(row);
    // Normalize: convert null → "", ISO datetimes → input-friendly
    const next: Record<string, any> = { ...defaultRow };
    for (const k of Object.keys(defaultRow)) {
      let v = row[k];
      if (v === null || v === undefined) v = "";
      else if (typeof v === "string" && /^\d{4}-\d{2}-\d{2}T/.test(v)) {
        // datetime-local expects yyyy-MM-ddTHH:mm
        v = v.slice(0, 16);
      }
      next[k] = v;
    }
    setForm(next);
    setOpen(true);
  }

  function closeDialog() {
    setOpen(false);
    setEditing(null);
    setForm(defaultRow);
  }

  const filtered = useMemo(() => {
    if (!search.trim()) return rows as any[];
    const q = search.toLowerCase();
    const keys = searchKeys ?? columns.filter((c) => c.searchable !== false).map((c) => c.key);
    return (rows as any[]).filter((r) =>
      keys.some((k) => {
        const v = k.split(".").reduce((acc: any, p) => acc?.[p], r);
        return v != null && String(v).toLowerCase().includes(q);
      }),
    );
  }, [rows, search, columns, searchKeys]);

  function exportCsv() {
    const header = columns.map((c) => c.label).join(",");
    const escape = (v: any) => {
      const s = v == null ? "" : String(v);
      return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const body = filtered
      .map((row: any) =>
        columns
          .map((c) => {
            const v = c.key.split(".").reduce((acc: any, p) => acc?.[p], row);
            return escape(v);
          })
          .join(","),
      )
      .join("\n");
    const blob = new Blob([header + "\n" + body], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${table}-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <>
      <div className="flex flex-col sm:flex-row gap-2 sm:items-center sm:justify-between mb-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={`Search ${title.toLowerCase()}…`}
            className="pl-9"
          />
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={exportCsv} disabled={filtered.length === 0}>
            <Download className="h-4 w-4 mr-2" /> Export
          </Button>
          <Dialog open={open} onOpenChange={(v) => (v ? setOpen(true) : closeDialog())}>
            <DialogTrigger asChild>
              <Button onClick={openCreate}>
                <Plus className="h-4 w-4 mr-2" /> Add {title}
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="font-display text-2xl">
                  {editing ? `Edit ${title}` : `New ${title}`}
                </DialogTitle>
              </DialogHeader>
              <form
                className="space-y-4"
                onSubmit={(e) => {
                  e.preventDefault();
                  save.mutate(form);
                }}
              >
                {typeof formFields === "function" ? formFields(form, setForm) : formFields}
                <DialogFooter>
                  <Button type="button" variant="ghost" onClick={closeDialog}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={save.isPending}>
                    {save.isPending ? "Saving…" : editing ? "Save changes" : "Create"}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="luxe-card rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm min-w-[640px]">
            <thead className="bg-secondary/40 text-left">
              <tr>
                {columns.map((c) => (
                  <th key={c.key} className="px-4 py-3 font-medium text-xs uppercase tracking-wider text-muted-foreground">
                    {c.label}
                  </th>
                ))}
                <th className="px-4 py-3 w-24"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {isLoading && (
                <tr>
                  <td colSpan={columns.length + 1} className="p-8 text-center text-muted-foreground">
                    Loading…
                  </td>
                </tr>
              )}
              {!isLoading && filtered.length === 0 && (
                <tr>
                  <td colSpan={columns.length + 1} className="p-8 text-center text-muted-foreground">
                    {search ? "No matches." : emptyText}
                  </td>
                </tr>
              )}
              {filtered.map((row: any) => (
                <tr key={(rowKey ?? ((r) => r.id))(row)} className="hover:bg-secondary/20">
                  {columns.map((c) => (
                    <td key={c.key} className="px-4 py-3 align-top">
                      {c.render ? c.render(row) : (row as any)[c.key] ?? "—"}
                    </td>
                  ))}
                  <td className="px-4 py-3 text-right whitespace-nowrap">
                    <Button variant="ghost" size="icon" onClick={() => openEdit(row)} aria-label="Edit">
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => {
                        if (confirm("Delete this record?")) remove.mutate(row.id);
                      }}
                      aria-label="Delete"
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
