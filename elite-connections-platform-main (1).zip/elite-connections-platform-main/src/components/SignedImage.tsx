import { useQuery } from "@tanstack/react-query";
import { signedUrl } from "@/lib/storage";
import { cn } from "@/lib/utils";

export function SignedImage({
  bucket,
  path,
  alt,
  className,
  fallback,
}: {
  bucket: string;
  path?: string | null;
  alt: string;
  className?: string;
  fallback?: React.ReactNode;
}) {
  const { data: url } = useQuery({
    queryKey: ["signed", bucket, path],
    enabled: !!path,
    staleTime: 1000 * 60 * 30,
    queryFn: () => signedUrl(bucket, path!, 60 * 60),
  });
  if (!path) return <>{fallback ?? null}</>;
  if (!url) return <div className={cn("animate-pulse bg-secondary", className)} />;
  return <img src={url} alt={alt} className={className} loading="lazy" />;
}
