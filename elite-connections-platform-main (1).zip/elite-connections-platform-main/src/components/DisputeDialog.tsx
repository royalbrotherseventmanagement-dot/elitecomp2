import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";

export function DisputeDialog({
  open, onClose, bookingId, eventTitle,
}: { open: boolean; onClose: () => void; bookingId: string; eventTitle?: string }) {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [category, setCategory] = useState("");
  const [reason, setReason] = useState("");

  const submit = useMutation({
    mutationFn: async () => {
      if (!user) throw new Error("Sign in required");
      const { error } = await supabase.from("disputes" as any).insert({
        booking_id: bookingId, opened_by: user.id, category, reason,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Dispute submitted. Our team will review it.");
      qc.invalidateQueries({ queryKey: ["disputes"] });
      setCategory(""); setReason(""); onClose();
    },
    onError: (e: any) => toast.error(e.message ?? "Failed"),
  });

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl">Open a dispute</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          {eventTitle && <p className="text-sm text-muted-foreground">For: <b>{eventTitle}</b></p>}
          <div className="space-y-1.5">
            <Label>Category</Label>
            <Input required placeholder="No-show, payment issue, conduct…" value={category} onChange={(e) => setCategory(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label>What happened?</Label>
            <Textarea rows={5} required value={reason} onChange={(e) => setReason(e.target.value)} />
          </div>
        </div>
        <DialogFooter>
          <Button onClick={() => submit.mutate()} disabled={submit.isPending || !category || !reason} className="w-full">
            {submit.isPending ? "Submitting…" : "Submit dispute"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
