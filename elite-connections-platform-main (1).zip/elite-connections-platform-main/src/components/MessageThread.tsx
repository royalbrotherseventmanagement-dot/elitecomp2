import { useEffect, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Paperclip, Send, X, FileIcon } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/use-auth";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { SignedImage } from "@/components/SignedImage";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { formatBytes, sanitizeFilename } from "@/lib/format";

const MAX_ATTACHMENT_BYTES = 10 * 1024 * 1024; // 10 MB
const ALLOWED_MIME = [
  "image/png", "image/jpeg", "image/webp", "image/gif",
  "application/pdf",
];

type Msg = {
  id: string; booking_id: string; sender_id: string;
  body: string | null; created_at: string;
  attachment_path: string | null; attachment_type: string | null; attachment_name: string | null;
};

function AttachmentLink({ path, name }: { path: string; name: string }) {
  async function open() {
    const { data } = await supabase.storage.from("chat-media").createSignedUrl(path, 60);
    if (data?.signedUrl) window.open(data.signedUrl, "_blank");
  }
  return (
    <button type="button" onClick={open} className="inline-flex items-center gap-2 text-sm underline">
      <FileIcon className="h-4 w-4" /> {name || "attachment"}
    </button>
  );
}

export function MessageThread({ bookingId }: { bookingId: string }) {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [draft, setDraft] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [sending, setSending] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const { data: messages = [] } = useQuery({
    queryKey: ["messages", bookingId],
    enabled: !!bookingId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("messages" as any)
        .select("id, booking_id, sender_id, body, created_at, attachment_path, attachment_type, attachment_name")
        .eq("booking_id", bookingId)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return (data ?? []) as unknown as Msg[];
    },
  });

  useEffect(() => {
    const channel = supabase
      .channel(`messages:${bookingId}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "messages", filter: `booking_id=eq.${bookingId}` },
        (payload) => {
          qc.setQueryData<Msg[]>(["messages", bookingId], (prev = []) => {
            const next = payload.new as Msg;
            if (prev.some((m) => m.id === next.id)) return prev;
            return [...prev, next];
          });
        },
      )
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [bookingId, qc]);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages.length]);

  async function send(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;
    if (!draft.trim() && !file) return;
    setSending(true);
    try {
      let attachment_path: string | null = null;
      let attachment_type: string | null = null;
      let attachment_name: string | null = null;
      if (file) {
        if (file.size > MAX_ATTACHMENT_BYTES) throw new Error("File exceeds 10 MB limit");
        if (file.type && !ALLOWED_MIME.includes(file.type)) throw new Error("Unsupported file type");
        const safeName = sanitizeFilename(file.name);
        const ext = safeName.includes(".") ? safeName.split(".").pop() : "bin";
        const path = `${bookingId}/${crypto.randomUUID()}.${ext}`;
        const { error: ue } = await supabase.storage.from("chat-media").upload(path, file, {
          contentType: file.type || "application/octet-stream", upsert: false,
        });
        if (ue) throw ue;
        attachment_path = path;
        attachment_type = file.type;
        attachment_name = safeName;
      }
      const body = draft.trim() || null;
      const { error } = await supabase.from("messages" as any).insert({
        booking_id: bookingId, sender_id: user.id, body,
        attachment_path, attachment_type, attachment_name,
      });
      if (error) throw error;
      setDraft(""); setFile(null);
      if (fileRef.current) fileRef.current.value = "";
    } catch (err: any) {
      toast.error(err.message ?? "Failed to send");
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="flex flex-col h-[60vh] luxe-card rounded-xl overflow-hidden">
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.length === 0 && (
          <div className="text-sm text-muted-foreground text-center py-12">No messages yet. Say hello.</div>
        )}
        {messages.map((m) => {
          const mine = m.sender_id === user?.id;
          const isImage = m.attachment_type?.startsWith("image/");
          return (
            <div key={m.id} className={cn("flex", mine ? "justify-end" : "justify-start")}>
              <div className={cn(
                "max-w-[75%] rounded-2xl px-4 py-2 text-sm whitespace-pre-wrap",
                mine ? "bg-[color:var(--gold)]/15 border border-[color:var(--gold)]/30" : "bg-secondary",
              )}>
                {m.attachment_path && isImage && (
                  <div className="rounded-lg overflow-hidden mb-1 max-w-xs">
                    <SignedImage bucket="chat-media" path={m.attachment_path} alt={m.attachment_name ?? ""} className="max-w-full h-auto" />
                  </div>
                )}
                {m.attachment_path && !isImage && (
                  <div className="mb-1">
                    <AttachmentLink path={m.attachment_path} name={m.attachment_name ?? "file"} />
                  </div>
                )}
                {m.body && <div>{m.body}</div>}
                <div className="text-[10px] mt-1 opacity-60">
                  {new Date(m.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                </div>
              </div>
            </div>
          );
        })}
        <div ref={endRef} />
      </div>
      <form onSubmit={send} className="border-t border-border p-3 space-y-2">
        {file && (
          <div className="flex items-center gap-2 text-xs bg-secondary rounded px-2 py-1">
            <FileIcon className="h-3 w-3" />
            <span className="truncate flex-1">{file.name} <span className="text-muted-foreground">· {formatBytes(file.size)}</span></span>
            <button type="button" onClick={() => { setFile(null); if (fileRef.current) fileRef.current.value = ""; }}>
              <X className="h-3 w-3" />
            </button>
          </div>
        )}
        <div className="flex gap-2">
          <input
            ref={fileRef}
            type="file"
            className="hidden"
            accept={ALLOWED_MIME.join(",")}
            onChange={(e) => {
              const f = e.target.files?.[0] ?? null;
              if (!f) return setFile(null);
              if (f.size > MAX_ATTACHMENT_BYTES) { toast.error("File exceeds 10 MB"); e.target.value = ""; return; }
              if (f.type && !ALLOWED_MIME.includes(f.type)) { toast.error("Unsupported file type"); e.target.value = ""; return; }
              setFile(f);
            }}
          />
          <Button type="button" variant="ghost" size="icon" onClick={() => fileRef.current?.click()}>
            <Paperclip className="h-4 w-4" />
          </Button>
          <Textarea
            rows={1}
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(e as any); } }}
            placeholder="Write a message…"
            className="min-h-10 resize-none"
          />
          <Button type="submit" disabled={sending || (!draft.trim() && !file)} size="icon">
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </form>
    </div>
  );
}
