
-- Dispute evidence
CREATE TABLE public.dispute_evidence (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  dispute_id uuid NOT NULL REFERENCES public.disputes(id) ON DELETE CASCADE,
  uploader_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  storage_path text NOT NULL,
  file_name text NOT NULL,
  file_type text,
  file_size integer,
  note text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, DELETE ON public.dispute_evidence TO authenticated;
GRANT ALL ON public.dispute_evidence TO service_role;
ALTER TABLE public.dispute_evidence ENABLE ROW LEVEL SECURITY;

CREATE POLICY "evidence_select_participants_or_staff" ON public.dispute_evidence
FOR SELECT TO authenticated USING (
  public.has_role(auth.uid(), 'admin')
  OR public.has_role(auth.uid(), 'agent')
  OR uploader_id = auth.uid()
  OR EXISTS (
    SELECT 1 FROM public.disputes d
    JOIN public.bookings b ON b.id = d.booking_id
    LEFT JOIN public.talent t ON t.id = b.talent_id
    LEFT JOIN public.clients c ON c.id = b.client_id
    WHERE d.id = dispute_evidence.dispute_id
      AND (t.profile_user_id = auth.uid() OR c.profile_user_id = auth.uid() OR d.opened_by = auth.uid())
  )
);

CREATE POLICY "evidence_insert_participants_or_staff" ON public.dispute_evidence
FOR INSERT TO authenticated WITH CHECK (
  uploader_id = auth.uid() AND (
    public.has_role(auth.uid(), 'admin')
    OR public.has_role(auth.uid(), 'agent')
    OR EXISTS (
      SELECT 1 FROM public.disputes d
      JOIN public.bookings b ON b.id = d.booking_id
      LEFT JOIN public.talent t ON t.id = b.talent_id
      LEFT JOIN public.clients c ON c.id = b.client_id
      WHERE d.id = dispute_id
        AND (t.profile_user_id = auth.uid() OR c.profile_user_id = auth.uid() OR d.opened_by = auth.uid())
    )
  )
);

CREATE POLICY "evidence_delete_own_or_staff" ON public.dispute_evidence
FOR DELETE TO authenticated USING (
  uploader_id = auth.uid() OR public.has_role(auth.uid(), 'admin')
);

-- Review moderation audit
CREATE TABLE public.review_moderation_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  review_id uuid NOT NULL REFERENCES public.reviews(id) ON DELETE CASCADE,
  moderator_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  prev_status text,
  new_status text NOT NULL,
  note text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.review_moderation_log TO authenticated;
GRANT ALL ON public.review_moderation_log TO service_role;
ALTER TABLE public.review_moderation_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "rmlog_select_staff" ON public.review_moderation_log
FOR SELECT TO authenticated USING (
  public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'agent')
);

CREATE OR REPLACE FUNCTION public.tg_log_review_moderation()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    INSERT INTO public.review_moderation_log(review_id, moderator_id, prev_status, new_status, note)
    VALUES (NEW.id, NULL, NULL, COALESCE(NEW.moderation_status::text, 'pending'), 'created');
  ELSIF TG_OP = 'UPDATE' AND NEW.moderation_status IS DISTINCT FROM OLD.moderation_status THEN
    INSERT INTO public.review_moderation_log(review_id, moderator_id, prev_status, new_status, note)
    VALUES (NEW.id, NEW.moderated_by, OLD.moderation_status::text, NEW.moderation_status::text, NEW.moderator_note);
  END IF;
  RETURN NEW;
END; $$;

DROP TRIGGER IF EXISTS trg_log_review_moderation ON public.reviews;
CREATE TRIGGER trg_log_review_moderation
AFTER INSERT OR UPDATE ON public.reviews
FOR EACH ROW EXECUTE FUNCTION public.tg_log_review_moderation();

-- Storage RLS for dispute-evidence bucket
CREATE POLICY "dispute_evidence_read" ON storage.objects FOR SELECT TO authenticated USING (
  bucket_id = 'dispute-evidence' AND (
    public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'agent')
    OR EXISTS (
      SELECT 1 FROM public.dispute_evidence ev
      WHERE ev.storage_path = storage.objects.name
        AND (
          ev.uploader_id = auth.uid()
          OR EXISTS (
            SELECT 1 FROM public.disputes d
            JOIN public.bookings b ON b.id = d.booking_id
            LEFT JOIN public.talent t ON t.id = b.talent_id
            LEFT JOIN public.clients c ON c.id = b.client_id
            WHERE d.id = ev.dispute_id
              AND (t.profile_user_id = auth.uid() OR c.profile_user_id = auth.uid() OR d.opened_by = auth.uid())
          )
        )
    )
  )
);

CREATE POLICY "dispute_evidence_insert" ON storage.objects FOR INSERT TO authenticated WITH CHECK (
  bucket_id = 'dispute-evidence' AND owner = auth.uid()
);

CREATE POLICY "dispute_evidence_delete" ON storage.objects FOR DELETE TO authenticated USING (
  bucket_id = 'dispute-evidence' AND (owner = auth.uid() OR public.has_role(auth.uid(), 'admin'))
);
