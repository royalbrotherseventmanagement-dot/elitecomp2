
DROP VIEW IF EXISTS public.talent_public;
CREATE VIEW public.talent_public WITH (security_invoker = on) AS
SELECT id, stage_name, city, category, tier, avatar_url, bio,
       day_rate, hourly_rate, languages, height_cm, gender,
       status, verification_status, created_at
FROM public.talent
WHERE status = 'active' AND verification_status = 'verified';
GRANT SELECT ON public.talent_public TO anon, authenticated;

-- Allow row access for browse but restrict sensitive columns for anon
CREATE POLICY talent_browse_safe ON public.talent
  FOR SELECT TO anon, authenticated
  USING (status='active' AND verification_status='verified');

REVOKE SELECT ON public.talent FROM anon;
GRANT SELECT (id, stage_name, city, category, tier, avatar_url, bio,
              day_rate, hourly_rate, languages, height_cm, gender,
              status, verification_status, created_at, profile_user_id)
  ON public.talent TO anon;
