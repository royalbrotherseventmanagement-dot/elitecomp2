
-- ============== MESSAGES (with attachments) ==============
CREATE TABLE public.messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id uuid NOT NULL REFERENCES public.bookings(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  body text,
  attachment_path text,
  attachment_type text,
  attachment_name text,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT messages_has_content CHECK (
    (body IS NOT NULL AND length(btrim(body)) > 0) OR attachment_path IS NOT NULL
  )
);
CREATE INDEX idx_messages_booking ON public.messages(booking_id, created_at);

GRANT SELECT, INSERT ON public.messages TO authenticated;
GRANT ALL ON public.messages TO service_role;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Participants and staff read messages" ON public.messages
  FOR SELECT TO authenticated USING (
    public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'agent')
    OR EXISTS (SELECT 1 FROM public.bookings b WHERE b.id = booking_id
      AND (public.is_talent_owner(auth.uid(), b.talent_id) OR public.is_client_owner(auth.uid(), b.client_id)))
  );
CREATE POLICY "Participants and staff send messages" ON public.messages
  FOR INSERT TO authenticated WITH CHECK (
    sender_id = auth.uid() AND (
      public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'agent')
      OR EXISTS (SELECT 1 FROM public.bookings b WHERE b.id = booking_id
        AND (public.is_talent_owner(auth.uid(), b.talent_id) OR public.is_client_owner(auth.uid(), b.client_id)))
    )
  );

ALTER PUBLICATION supabase_realtime ADD TABLE public.messages;
ALTER TABLE public.messages REPLICA IDENTITY FULL;

-- Storage policies for chat-media bucket (bucket created separately)
CREATE POLICY "Chat media read" ON storage.objects FOR SELECT TO authenticated USING (
  bucket_id = 'chat-media' AND (
    public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'agent')
    OR EXISTS (SELECT 1 FROM public.bookings b WHERE b.id::text = (storage.foldername(name))[1]
      AND (public.is_talent_owner(auth.uid(), b.talent_id) OR public.is_client_owner(auth.uid(), b.client_id)))
  )
);
CREATE POLICY "Chat media upload" ON storage.objects FOR INSERT TO authenticated WITH CHECK (
  bucket_id = 'chat-media' AND (
    public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'agent')
    OR EXISTS (SELECT 1 FROM public.bookings b WHERE b.id::text = (storage.foldername(name))[1]
      AND (public.is_talent_owner(auth.uid(), b.talent_id) OR public.is_client_owner(auth.uid(), b.client_id)))
  )
);

-- ============== REVIEWS (with moderation) ==============
CREATE TYPE public.review_status AS ENUM ('pending','approved','rejected');

CREATE TABLE public.reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id uuid NOT NULL UNIQUE REFERENCES public.bookings(id) ON DELETE CASCADE,
  talent_id uuid NOT NULL REFERENCES public.talent(id) ON DELETE CASCADE,
  client_id uuid NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  rating smallint NOT NULL CHECK (rating BETWEEN 1 AND 5),
  body text,
  is_published boolean NOT NULL DEFAULT false,
  moderation_status public.review_status NOT NULL DEFAULT 'pending',
  moderator_note text,
  moderated_by uuid REFERENCES auth.users(id),
  moderated_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_reviews_talent ON public.reviews(talent_id);

GRANT SELECT ON public.reviews TO anon;
GRANT SELECT, INSERT, UPDATE ON public.reviews TO authenticated;
GRANT ALL ON public.reviews TO service_role;
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Read approved reviews or own" ON public.reviews FOR SELECT TO anon, authenticated
  USING (
    (moderation_status = 'approved' AND is_published)
    OR public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'agent')
    OR public.is_client_owner(auth.uid(), client_id)
  );
CREATE POLICY "Client creates review for own completed booking" ON public.reviews
  FOR INSERT TO authenticated WITH CHECK (
    public.is_client_owner(auth.uid(), client_id)
    AND EXISTS (SELECT 1 FROM public.bookings b WHERE b.id = booking_id
      AND b.client_id = reviews.client_id AND b.talent_id = reviews.talent_id AND b.status = 'completed')
  );
CREATE POLICY "Staff manage reviews" ON public.reviews FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'agent'))
  WITH CHECK (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'agent'));

CREATE TRIGGER trg_reviews_updated_at BEFORE UPDATE ON public.reviews
  FOR EACH ROW EXECUTE FUNCTION public.tg_set_updated_at();

-- ============== NOTIFICATIONS ==============
CREATE TABLE public.notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  type text NOT NULL,
  title text NOT NULL,
  body text,
  link text,
  read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_notifications_user ON public.notifications(user_id, created_at DESC);
GRANT SELECT, UPDATE ON public.notifications TO authenticated;
GRANT ALL ON public.notifications TO service_role;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users read own notifications" ON public.notifications
  FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "Users update own notifications" ON public.notifications
  FOR UPDATE TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;
ALTER TABLE public.notifications REPLICA IDENTITY FULL;

CREATE OR REPLACE FUNCTION public.notify_user(_user_id uuid, _type text, _title text, _body text, _link text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
  IF _user_id IS NULL THEN RETURN; END IF;
  INSERT INTO public.notifications(user_id, type, title, body, link) VALUES (_user_id, _type, _title, _body, _link);
END; $$;

CREATE OR REPLACE FUNCTION public.tg_notify_booking_request()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE talent_user uuid; staff uuid;
BEGIN
  IF TG_OP = 'INSERT' THEN
    SELECT profile_user_id INTO talent_user FROM public.talent WHERE id = NEW.talent_id;
    PERFORM public.notify_user(talent_user, 'booking_request', 'New booking request', NEW.event_title, '/requests');
    FOR staff IN SELECT user_id FROM public.user_roles WHERE role IN ('admin','agent') LOOP
      PERFORM public.notify_user(staff, 'booking_request', 'New booking request', NEW.event_title, '/requests');
    END LOOP;
  ELSIF TG_OP = 'UPDATE' AND NEW.status IS DISTINCT FROM OLD.status THEN
    PERFORM public.notify_user(NEW.requester_user_id, 'booking_request_status', 'Request ' || NEW.status::text, NEW.event_title, '/my-bookings');
  END IF;
  RETURN NEW;
END; $$;
CREATE TRIGGER trg_notify_booking_request AFTER INSERT OR UPDATE ON public.booking_requests
  FOR EACH ROW EXECUTE FUNCTION public.tg_notify_booking_request();

CREATE OR REPLACE FUNCTION public.tg_notify_booking()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE talent_user uuid; client_user uuid;
BEGIN
  SELECT profile_user_id INTO talent_user FROM public.talent WHERE id = NEW.talent_id;
  SELECT profile_user_id INTO client_user FROM public.clients WHERE id = NEW.client_id;
  IF TG_OP = 'INSERT' THEN
    PERFORM public.notify_user(talent_user, 'booking_new', 'Booking confirmed', NEW.event_title, '/my-bookings');
    PERFORM public.notify_user(client_user, 'booking_new', 'Booking confirmed', NEW.event_title, '/my-bookings');
  ELSIF TG_OP = 'UPDATE' AND NEW.status IS DISTINCT FROM OLD.status THEN
    PERFORM public.notify_user(talent_user, 'booking_status', 'Booking ' || NEW.status::text, NEW.event_title, '/my-bookings');
    PERFORM public.notify_user(client_user, 'booking_status', 'Booking ' || NEW.status::text, NEW.event_title, '/my-bookings');
  END IF;
  RETURN NEW;
END; $$;
CREATE TRIGGER trg_notify_booking AFTER INSERT OR UPDATE ON public.bookings
  FOR EACH ROW EXECUTE FUNCTION public.tg_notify_booking();

CREATE OR REPLACE FUNCTION public.tg_notify_message()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE talent_user uuid; client_user uuid; b_title text;
BEGIN
  SELECT t.profile_user_id, c.profile_user_id, bk.event_title INTO talent_user, client_user, b_title
  FROM public.bookings bk
  LEFT JOIN public.talent t ON t.id = bk.talent_id
  LEFT JOIN public.clients c ON c.id = bk.client_id
  WHERE bk.id = NEW.booking_id;
  IF talent_user IS NOT NULL AND talent_user <> NEW.sender_id THEN
    PERFORM public.notify_user(talent_user, 'message', 'New message', b_title, '/messages/' || NEW.booking_id);
  END IF;
  IF client_user IS NOT NULL AND client_user <> NEW.sender_id THEN
    PERFORM public.notify_user(client_user, 'message', 'New message', b_title, '/messages/' || NEW.booking_id);
  END IF;
  RETURN NEW;
END; $$;
CREATE TRIGGER trg_notify_message AFTER INSERT ON public.messages
  FOR EACH ROW EXECUTE FUNCTION public.tg_notify_message();

CREATE OR REPLACE FUNCTION public.tg_notify_review()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE staff uuid; talent_user uuid;
BEGIN
  IF TG_OP = 'INSERT' THEN
    FOR staff IN SELECT user_id FROM public.user_roles WHERE role IN ('admin','agent') LOOP
      PERFORM public.notify_user(staff, 'review_pending', 'Review awaiting moderation', NULL, '/reviews');
    END LOOP;
  ELSIF TG_OP = 'UPDATE' AND NEW.moderation_status IS DISTINCT FROM OLD.moderation_status THEN
    SELECT profile_user_id INTO talent_user FROM public.talent WHERE id = NEW.talent_id;
    PERFORM public.notify_user(talent_user, 'review_moderated', 'Review ' || NEW.moderation_status::text, NULL, '/my-profile');
  END IF;
  RETURN NEW;
END; $$;
CREATE TRIGGER trg_notify_review AFTER INSERT OR UPDATE ON public.reviews
  FOR EACH ROW EXECUTE FUNCTION public.tg_notify_review();

-- ============== DISPUTES ==============
CREATE TYPE public.dispute_status AS ENUM ('open','under_review','resolved','rejected');

CREATE TABLE public.disputes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id uuid NOT NULL REFERENCES public.bookings(id) ON DELETE CASCADE,
  opened_by uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  category text NOT NULL,
  reason text NOT NULL,
  status public.dispute_status NOT NULL DEFAULT 'open',
  resolution text,
  resolved_by uuid REFERENCES auth.users(id),
  resolved_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_disputes_status ON public.disputes(status, created_at DESC);
GRANT SELECT, INSERT, UPDATE ON public.disputes TO authenticated;
GRANT ALL ON public.disputes TO service_role;
ALTER TABLE public.disputes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Participants and staff read disputes" ON public.disputes
  FOR SELECT TO authenticated USING (
    opened_by = auth.uid()
    OR public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'agent')
    OR EXISTS (SELECT 1 FROM public.bookings b WHERE b.id = booking_id
      AND (public.is_talent_owner(auth.uid(), b.talent_id) OR public.is_client_owner(auth.uid(), b.client_id)))
  );
CREATE POLICY "Participants open disputes" ON public.disputes
  FOR INSERT TO authenticated WITH CHECK (
    opened_by = auth.uid()
    AND EXISTS (SELECT 1 FROM public.bookings b WHERE b.id = booking_id
      AND (public.is_talent_owner(auth.uid(), b.talent_id) OR public.is_client_owner(auth.uid(), b.client_id)))
  );
CREATE POLICY "Staff resolve disputes" ON public.disputes FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'agent'))
  WITH CHECK (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'agent'));

CREATE TRIGGER trg_disputes_updated_at BEFORE UPDATE ON public.disputes
  FOR EACH ROW EXECUTE FUNCTION public.tg_set_updated_at();

CREATE OR REPLACE FUNCTION public.tg_notify_dispute()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE staff uuid; talent_user uuid; client_user uuid;
BEGIN
  SELECT t.profile_user_id, c.profile_user_id INTO talent_user, client_user
  FROM public.bookings b
  LEFT JOIN public.talent t ON t.id = b.talent_id
  LEFT JOIN public.clients c ON c.id = b.client_id
  WHERE b.id = NEW.booking_id;
  IF TG_OP = 'INSERT' THEN
    FOR staff IN SELECT user_id FROM public.user_roles WHERE role IN ('admin','agent') LOOP
      PERFORM public.notify_user(staff, 'dispute_open', 'New dispute opened', NEW.category, '/disputes');
    END LOOP;
  ELSIF TG_OP = 'UPDATE' AND NEW.status IS DISTINCT FROM OLD.status THEN
    PERFORM public.notify_user(NEW.opened_by, 'dispute_update', 'Dispute ' || NEW.status::text, NEW.category, '/disputes');
    IF talent_user IS NOT NULL AND talent_user <> NEW.opened_by THEN
      PERFORM public.notify_user(talent_user, 'dispute_update', 'Dispute ' || NEW.status::text, NEW.category, '/disputes');
    END IF;
    IF client_user IS NOT NULL AND client_user <> NEW.opened_by THEN
      PERFORM public.notify_user(client_user, 'dispute_update', 'Dispute ' || NEW.status::text, NEW.category, '/disputes');
    END IF;
  END IF;
  RETURN NEW;
END; $$;
CREATE TRIGGER trg_notify_dispute AFTER INSERT OR UPDATE ON public.disputes
  FOR EACH ROW EXECUTE FUNCTION public.tg_notify_dispute();
