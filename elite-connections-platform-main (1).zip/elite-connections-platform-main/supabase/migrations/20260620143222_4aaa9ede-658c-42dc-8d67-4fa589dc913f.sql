
-- 1) Booking requests: allow linked client to SELECT
CREATE POLICY br_client_select ON public.booking_requests
  FOR SELECT TO authenticated
  USING (client_id IS NOT NULL AND public.is_client_owner(auth.uid(), client_id));

-- 2) Chat media: DELETE policy for participants and staff
CREATE POLICY "Chat media delete" ON storage.objects
  FOR DELETE TO authenticated
  USING (
    bucket_id = 'chat-media' AND (
      public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'agent') OR
      EXISTS (
        SELECT 1 FROM public.bookings b
        WHERE b.id::text = (storage.foldername(objects.name))[1]
          AND (public.is_talent_owner(auth.uid(), b.talent_id) OR public.is_client_owner(auth.uid(), b.client_id))
      )
    )
  );

-- 3) Verification docs: owner SELECT
CREATE POLICY vd_owner_read ON storage.objects
  FOR SELECT TO authenticated
  USING (
    bucket_id = 'verification-docs'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

-- 4) Lock down internal SECURITY DEFINER functions from public/auth callers
REVOKE EXECUTE ON FUNCTION public.notify_user(uuid, text, text, text, text) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.tg_booking_commission() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.tg_set_updated_at() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.tg_notify_booking_request() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.tg_notify_booking() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.tg_notify_message() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.tg_notify_dispute() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.tg_notify_review() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.tg_log_review_moderation() FROM PUBLIC, anon, authenticated;
