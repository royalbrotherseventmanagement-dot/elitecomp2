
-- Verification status + new columns on talent
CREATE TYPE public.verification_status AS ENUM ('unsubmitted','submitted','verified','rejected');

ALTER TABLE public.talent
  ADD COLUMN profile_user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN verification_status public.verification_status NOT NULL DEFAULT 'unsubmitted',
  ADD COLUMN id_document_url text,
  ADD COLUMN id_document_back_url text,
  ADD COLUMN verification_note text,
  ADD COLUMN verification_submitted_at timestamptz,
  ADD COLUMN verification_reviewed_at timestamptz,
  ADD COLUMN verification_reviewed_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN verification_rejection_reason text;

CREATE UNIQUE INDEX talent_profile_user_id_key ON public.talent(profile_user_id) WHERE profile_user_id IS NOT NULL;

ALTER TABLE public.clients
  ADD COLUMN profile_user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL;

CREATE UNIQUE INDEX clients_profile_user_id_key ON public.clients(profile_user_id) WHERE profile_user_id IS NOT NULL;

CREATE OR REPLACE FUNCTION public.is_talent_owner(_user_id uuid, _talent_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.talent WHERE id = _talent_id AND profile_user_id = _user_id);
$$;

CREATE OR REPLACE FUNCTION public.is_client_owner(_user_id uuid, _client_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.clients WHERE id = _client_id AND profile_user_id = _user_id);
$$;

CREATE TABLE public.talent_media (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  talent_id uuid NOT NULL REFERENCES public.talent(id) ON DELETE CASCADE,
  url text NOT NULL,
  storage_path text,
  caption text,
  sort_order int NOT NULL DEFAULT 0,
  is_public boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX talent_media_talent_id_idx ON public.talent_media(talent_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.talent_media TO authenticated;
GRANT SELECT ON public.talent_media TO anon;
GRANT ALL ON public.talent_media TO service_role;
ALTER TABLE public.talent_media ENABLE ROW LEVEL SECURITY;

CREATE POLICY talent_media_public_read ON public.talent_media FOR SELECT TO anon, authenticated
  USING (is_public AND EXISTS (SELECT 1 FROM public.talent t WHERE t.id = talent_id AND t.status = 'active' AND t.verification_status = 'verified'));
CREATE POLICY talent_media_owner_all ON public.talent_media FOR ALL TO authenticated
  USING (public.is_talent_owner(auth.uid(), talent_id))
  WITH CHECK (public.is_talent_owner(auth.uid(), talent_id));
CREATE POLICY talent_media_admin_all ON public.talent_media FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'agent'))
  WITH CHECK (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'agent'));

CREATE TYPE public.booking_request_status AS ENUM ('pending','approved','rejected','cancelled','converted');

CREATE TABLE public.booking_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  talent_id uuid NOT NULL REFERENCES public.talent(id) ON DELETE RESTRICT,
  client_id uuid REFERENCES public.clients(id) ON DELETE SET NULL,
  requester_user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  event_title text NOT NULL,
  location text,
  starts_at timestamptz NOT NULL,
  ends_at timestamptz NOT NULL,
  budget numeric(12,2),
  message text,
  status public.booking_request_status NOT NULL DEFAULT 'pending',
  admin_note text,
  reviewed_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  reviewed_at timestamptz,
  booking_id uuid REFERENCES public.bookings(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX booking_requests_status_idx ON public.booking_requests(status);
CREATE INDEX booking_requests_requester_idx ON public.booking_requests(requester_user_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.booking_requests TO authenticated;
GRANT ALL ON public.booking_requests TO service_role;
ALTER TABLE public.booking_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY br_admin_all ON public.booking_requests FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'agent'))
  WITH CHECK (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'agent'));
CREATE POLICY br_requester_select ON public.booking_requests FOR SELECT TO authenticated
  USING (requester_user_id = auth.uid());
CREATE POLICY br_requester_insert ON public.booking_requests FOR INSERT TO authenticated
  WITH CHECK (requester_user_id = auth.uid());
CREATE POLICY br_requester_cancel ON public.booking_requests FOR UPDATE TO authenticated
  USING (requester_user_id = auth.uid() AND status = 'pending')
  WITH CHECK (requester_user_id = auth.uid() AND status IN ('pending','cancelled'));
CREATE POLICY br_talent_select ON public.booking_requests FOR SELECT TO authenticated
  USING (public.is_talent_owner(auth.uid(), talent_id));

CREATE TRIGGER booking_requests_updated_at BEFORE UPDATE ON public.booking_requests
  FOR EACH ROW EXECUTE FUNCTION public.tg_set_updated_at();

CREATE POLICY talent_public_browse ON public.talent FOR SELECT TO anon, authenticated
  USING (status = 'active' AND verification_status = 'verified');
CREATE POLICY talent_owner_read ON public.talent FOR SELECT TO authenticated
  USING (profile_user_id = auth.uid());
CREATE POLICY talent_owner_update ON public.talent FOR UPDATE TO authenticated
  USING (profile_user_id = auth.uid())
  WITH CHECK (profile_user_id = auth.uid());
CREATE POLICY talent_agent_all ON public.talent FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'agent'))
  WITH CHECK (public.has_role(auth.uid(),'agent'));

CREATE POLICY clients_owner_read ON public.clients FOR SELECT TO authenticated
  USING (profile_user_id = auth.uid());
CREATE POLICY clients_owner_update ON public.clients FOR UPDATE TO authenticated
  USING (profile_user_id = auth.uid())
  WITH CHECK (profile_user_id = auth.uid());
CREATE POLICY clients_owner_insert ON public.clients FOR INSERT TO authenticated
  WITH CHECK (profile_user_id = auth.uid());
CREATE POLICY clients_agent_all ON public.clients FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'agent'))
  WITH CHECK (public.has_role(auth.uid(),'agent'));

CREATE POLICY bookings_agent_all ON public.bookings FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'agent'))
  WITH CHECK (public.has_role(auth.uid(),'agent'));
CREATE POLICY bookings_talent_read ON public.bookings FOR SELECT TO authenticated
  USING (public.is_talent_owner(auth.uid(), talent_id));
CREATE POLICY bookings_client_read ON public.bookings FOR SELECT TO authenticated
  USING (public.is_client_owner(auth.uid(), client_id));

CREATE POLICY payouts_agent_all ON public.payouts FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'agent'))
  WITH CHECK (public.has_role(auth.uid(),'agent'));
CREATE POLICY payouts_talent_read ON public.payouts FOR SELECT TO authenticated
  USING (public.is_talent_owner(auth.uid(), talent_id));

CREATE POLICY invoices_agent_all ON public.invoices FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'agent'))
  WITH CHECK (public.has_role(auth.uid(),'agent'));
CREATE POLICY invoices_client_read ON public.invoices FOR SELECT TO authenticated
  USING (public.is_client_owner(auth.uid(), client_id));

CREATE POLICY contracts_agent_all ON public.contracts FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'agent'))
  WITH CHECK (public.has_role(auth.uid(),'agent'));
CREATE POLICY contracts_party_read ON public.contracts FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.bookings b WHERE b.id = contracts.booking_id
      AND (public.is_talent_owner(auth.uid(), b.talent_id) OR public.is_client_owner(auth.uid(), b.client_id))
  ));

DROP POLICY IF EXISTS user_roles_self_read ON public.user_roles;
CREATE POLICY user_roles_self_read ON public.user_roles FOR SELECT TO authenticated
  USING (user_id = auth.uid());

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  user_count integer;
  requested_role text;
  assigned_role public.app_role;
BEGIN
  INSERT INTO public.profiles (id, full_name, avatar_url)
  VALUES (NEW.id,
          COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', NEW.email),
          NEW.raw_user_meta_data->>'avatar_url');

  SELECT COUNT(*) INTO user_count FROM auth.users;

  IF user_count = 1 THEN
    assigned_role := 'admin';
  ELSE
    requested_role := NEW.raw_user_meta_data->>'requested_role';
    IF requested_role IN ('talent','client') THEN
      assigned_role := requested_role::public.app_role;
    ELSE
      assigned_role := 'client';
    END IF;
  END IF;

  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, assigned_role);

  IF assigned_role = 'talent' THEN
    INSERT INTO public.talent (stage_name, email, profile_user_id, status, verification_status)
    VALUES (COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email), NEW.email, NEW.id, 'on_hold', 'unsubmitted');
  ELSIF assigned_role = 'client' THEN
    INSERT INTO public.clients (full_name, email, profile_user_id)
    VALUES (COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email), NEW.email, NEW.id);
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
