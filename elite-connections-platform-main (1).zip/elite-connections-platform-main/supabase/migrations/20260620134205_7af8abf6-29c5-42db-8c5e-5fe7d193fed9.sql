
-- Avatars: owner-folder write, authenticated read
CREATE POLICY avatars_read ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'avatars');
CREATE POLICY avatars_write_own ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY avatars_update_own ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY avatars_delete_own ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);

-- Talent media
CREATE POLICY tm_read ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'talent-media');
CREATE POLICY tm_write_own ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'talent-media' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY tm_update_own ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id = 'talent-media' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY tm_delete_own ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'talent-media' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY tm_agent_all ON storage.objects FOR ALL TO authenticated
  USING (bucket_id = 'talent-media' AND (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'agent')))
  WITH CHECK (bucket_id = 'talent-media' AND (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'agent')));

-- Verification docs: talent uploads, only admins/agents read
CREATE POLICY vd_write_own ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'verification-docs' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY vd_admin_read ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'verification-docs' AND (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'agent')));
CREATE POLICY vd_admin_all ON storage.objects FOR ALL TO authenticated
  USING (bucket_id = 'verification-docs' AND (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'agent')))
  WITH CHECK (bucket_id = 'verification-docs' AND (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'agent')));
