
REVOKE EXECUTE ON FUNCTION public.tg_log_review_moderation() FROM PUBLIC, anon, authenticated;
