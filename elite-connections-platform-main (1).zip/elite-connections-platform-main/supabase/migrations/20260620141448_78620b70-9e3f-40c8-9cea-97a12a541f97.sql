
-- 1) Remove broad public SELECT on talent; add safe public view
DROP POLICY IF EXISTS talent_public_browse ON public.talent;

CREATE OR REPLACE VIEW public.talent_public AS
SELECT id, stage_name, city, category, tier, avatar_url, bio,
       day_rate, hourly_rate, languages, height_cm, gender,
       status, verification_status, created_at
FROM public.talent
WHERE status = 'active' AND verification_status = 'verified';

GRANT SELECT ON public.talent_public TO anon, authenticated;

-- 2) Realtime channel authorization
ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "rt_topic_authz" ON realtime.messages;
CREATE POLICY "rt_topic_authz" ON realtime.messages
FOR SELECT TO authenticated
USING (
  CASE
    WHEN realtime.topic() LIKE 'notif:%' THEN
      substring(realtime.topic() from 7)::uuid = auth.uid()
    WHEN realtime.topic() LIKE 'messages:%' THEN
      EXISTS (
        SELECT 1 FROM public.bookings b
        WHERE b.id = substring(realtime.topic() from 10)::uuid
          AND (
            public.is_talent_owner(auth.uid(), b.talent_id)
            OR public.is_client_owner(auth.uid(), b.client_id)
            OR public.has_role(auth.uid(), 'admin')
            OR public.has_role(auth.uid(), 'agent')
          )
      )
    ELSE false
  END
);

-- 3) Tighten avatars read
DROP POLICY IF EXISTS "avatars_read" ON storage.objects;
CREATE POLICY "avatars_read" ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id = 'avatars' AND (
    (storage.foldername(name))[1] = auth.uid()::text
    OR public.has_role(auth.uid(), 'admin')
    OR public.has_role(auth.uid(), 'agent')
    OR EXISTS (
      SELECT 1 FROM public.bookings b
      LEFT JOIN public.talent t ON t.id = b.talent_id
      LEFT JOIN public.clients c ON c.id = b.client_id
      WHERE ((storage.foldername(name))[1] = t.profile_user_id::text
             OR (storage.foldername(name))[1] = c.profile_user_id::text)
        AND (public.is_talent_owner(auth.uid(), b.talent_id)
             OR public.is_client_owner(auth.uid(), b.client_id))
    )
  )
);

-- 4) Tighten talent-media read
DROP POLICY IF EXISTS "tm_read" ON storage.objects;
CREATE POLICY "tm_read" ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id = 'talent-media' AND EXISTS (
    SELECT 1 FROM public.talent_media tm
    JOIN public.talent t ON t.id = tm.talent_id
    WHERE tm.storage_path = name
      AND (
        (tm.is_public AND t.status='active' AND t.verification_status='verified')
        OR public.is_talent_owner(auth.uid(), tm.talent_id)
        OR public.has_role(auth.uid(),'admin')
        OR public.has_role(auth.uid(),'agent')
      )
  )
);

-- 5) Revoke EXECUTE on internal SECURITY DEFINER funcs (only triggers call them)
REVOKE EXECUTE ON FUNCTION public.notify_user(uuid, text, text, text, text) FROM anon, authenticated, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM anon, authenticated, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.tg_booking_commission() FROM anon, authenticated, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.tg_set_updated_at() FROM anon, authenticated, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.tg_notify_review() FROM anon, authenticated, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.tg_notify_booking_request() FROM anon, authenticated, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.tg_log_review_moderation() FROM anon, authenticated, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.tg_notify_booking() FROM anon, authenticated, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.tg_notify_message() FROM anon, authenticated, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.tg_notify_dispute() FROM anon, authenticated, PUBLIC;
